
// src/api/staff/reportApi.js

// Mock Report Data
const attendanceData = [
    { date: '2023-10-25', totalCheckIns: 120, peakHour: '6 PM', uniqueMembers: 110 },
    { date: '2023-10-24', totalCheckIns: 115, peakHour: '7 PM', uniqueMembers: 105 },
    { date: '2023-10-23', totalCheckIns: 130, peakHour: '6 AM', uniqueMembers: 118 },
];

export const getDailyAttendanceReport = async (startDate, endDate) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    // Filter logic would go here
    return [...attendanceData];
};

export const getBookingReport = async () => {
    // Similar mock structure
    return [];
};

export const exportReportToCSV = (data, filename = 'report') => {
    if (!data || !data.length) return;
    const headers = Object.keys(data[0]).join(",");
    const csv = [headers, ...data.map(d => Object.values(d).join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${filename}.csv`;
    a.click();
};

export const exportReportToPDF = (data) => {
    alert("PDF Export initiated (Mock)");
};

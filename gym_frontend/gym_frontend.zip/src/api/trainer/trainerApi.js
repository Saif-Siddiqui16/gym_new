import { paginateData } from './trainerPagination';
import { filterData } from './trainerFilters';

// --- MOCK DATA ---

let assignedMembers = [
    {
        id: 1, name: 'Alex Thompson', memberId: 'M-10254', plan: 'Gold Plus', status: 'Active',
        attendance: '92%', lastSession: 'Yesterday', joined: 'Oct 2023', expiry: '2025-10-15',
        email: 'alex.t@example.com', phone: '+1 (555) 001-2345', location: 'Downtown Branch',
        sessionsDone: 48, totalSessions: 60, goal: 'Hypertrophy & Strength', isFlagged: false,
        recentWorkouts: [
            { id: 1, name: 'Heavy Squats & Leg Press', date: 'Yesterday', duration: '75 mins' },
            { id: 2, name: 'Chest Press & Bicep Curls', date: '3 days ago', duration: '60 mins' },
            { id: 3, name: 'HIIT & Mobility', date: '5 days ago', duration: '45 mins' }
        ]
    },
    {
        id: 2, name: 'Sarah Jenkins', memberId: 'M-10255', plan: 'Annual Elite', status: 'Active',
        attendance: '85%', lastSession: '2 days ago', joined: 'Jan 2024', expiry: '2025-01-20',
        email: 'sarah.j@example.com', phone: '+1 (555) 001-2346', location: 'Downtown Branch',
        sessionsDone: 30, totalSessions: 50, goal: 'Weight Loss', isFlagged: false,
        recentWorkouts: [
            { id: 1, name: 'Treadmill Sprints', date: '2 days ago', duration: '45 mins' },
            { id: 2, name: 'Yoga for Fat Loss', date: '4 days ago', duration: '60 mins' }
        ]
    },
    {
        id: 3, name: 'Michael Chen', memberId: 'M-10256', plan: 'Monthly Pro', status: 'Inactive',
        attendance: '45%', lastSession: '2 weeks ago', joined: 'Dec 2023', expiry: '2024-05-10',
        email: 'm.chen@example.com', phone: '+1 (555) 001-2347', location: 'Downtown Branch',
        sessionsDone: 12, totalSessions: 24, goal: 'Endurance', isFlagged: false,
        recentWorkouts: []
    },
    {
        id: 4, name: 'Emma Wilson', memberId: 'M-10257', plan: 'Gold Plus', status: 'Active',
        attendance: '100%', lastSession: 'Today', joined: 'March 2024', expiry: '2025-03-25',
        email: 'emma.w@example.com', phone: '+1 (555) 001-2348', location: 'Downtown Branch',
        sessionsDone: 15, totalSessions: 15, goal: 'Flexibility', isFlagged: false,
        recentWorkouts: [
            { id: 1, name: 'Advanced Pilates', date: 'Today', duration: '90 mins' }
        ]
    },
    {
        id: 5, name: 'David Miller', memberId: 'M-10258', plan: 'Annual Elite', status: 'Active',
        attendance: '78%', lastSession: 'Yesterday', joined: 'Feb 2024', expiry: '2025-02-14',
        email: 'd.miller@example.com', phone: '+1 (555) 001-2349', location: 'Downtown Branch',
        sessionsDone: 25, totalSessions: 40, goal: 'Muscle Gain', isFlagged: false,
        recentWorkouts: [
            { id: 1, name: 'Deadlift PR Attempt', date: 'Yesterday', duration: '60 mins' }
        ]
    },
];

let sessions = [
    { id: 1, title: 'CrossFit - Advanced Level', time: '07:00 AM - 08:30 AM', date: '2024-10-24', type: 'Group Class', location: 'Main Studio (Floor 1)', members: 12, maxMembers: 15, status: 'Confirmed', day: 24, color: 'blue' },
    { id: 2, title: 'Personal Training: Alex', time: '10:00 AM - 11:00 AM', date: '2024-10-24', type: 'One-on-One', location: 'PT Zone', members: 1, maxMembers: 1, status: 'Pending', day: 24, color: 'blue' },
    { id: 3, title: 'HIIT & Mobility', time: '05:30 PM - 06:30 PM', date: '2024-10-25', type: 'Group Class', location: 'Turf Area', members: 18, maxMembers: 20, status: 'Confirmed', day: 25, color: 'red' },
    { id: 4, title: 'Yoga Flow & Breathwork', time: '08:00 AM - 09:30 AM', date: '2024-10-27', type: 'Group Class', location: 'Zen Room', members: 8, maxMembers: 12, status: 'Confirmed', day: 27, color: 'purple' },
];

let sessionHistory = [
    {
        id: 1, workout: 'CrossFit - Advanced', date: '2026-02-04', time: '07:00 AM', total: 12, present: 10, absent: 2, type: 'Group Class',
        attendance: [
            { id: 1, name: 'Alex Thompson', status: 'present' },
            { id: 2, name: 'Sarah Jenkins', status: 'present' },
            { id: 3, name: 'Michael Chen', status: 'absent' },
            { id: 4, name: 'Emma Wilson', status: 'present' },
        ]
    },
    {
        id: 2, workout: 'Yoga Flow', date: '2026-02-03', time: '06:30 PM', total: 15, present: 15, absent: 0, type: 'Group Class',
        attendance: [
            { id: 1, name: 'Alex Thompson', status: 'present' },
            { id: 4, name: 'Emma Wilson', status: 'present' },
        ]
    },
    {
        id: 3, workout: 'Strength Training', date: '2026-02-02', time: '08:00 AM', total: 8, present: 6, absent: 2, type: 'Personal Training',
        attendance: [
            { id: 1, name: 'Alex Thompson', status: 'present' },
            { id: 5, name: 'David Miller', status: 'absent' },
        ]
    },
    {
        id: 4, workout: 'HIIT Blast', date: '2026-01-28', time: '05:00 PM', total: 20, present: 18, absent: 2, type: 'Group Class',
        attendance: [
            { id: 2, name: 'Sarah Jenkins', status: 'present' },
            { id: 3, name: 'Michael Chen', status: 'present' },
        ]
    },
];

let tasks = [
    { id: 1, title: 'Update Alex’s Diet Plan', assignedBy: 'Manager', priority: 'High', due: 'Today', status: 'Pending' },
    { id: 2, title: 'Check equipment in PT zone', assignedBy: 'Self', priority: 'Medium', due: 'Tomorrow', status: 'In Progress' },
    { id: 3, title: 'Prepare session notes for Yoga', assignedBy: 'Self', priority: 'Low', due: 'Completed', status: 'Completed' },
];

let trainerProfile = {
    id: 'TRN-2041',
    name: 'Coach John',
    email: 'john.trainer@newgym.com',
    phone: '+91 99887 76655',
    role: 'TRAINER',
    avatar: 'J',
    joinedDate: '2023-01-20',
    status: 'Active',
    lastLogin: '2024-03-15 07:45 AM',
    address: 'Indiranagar, Bangalore'
};

// --- HELPERS ---
const delay = (ms = 300) => new Promise(resolve => setTimeout(resolve, ms));

// --- PROFILE API ---
export const fetchTrainerProfile = async () => {
    await delay();
    return { ...trainerProfile };
};

export const updateTrainerProfile = async (updated) => {
    await delay();
    trainerProfile = { ...trainerProfile, ...updated };
    return { ...trainerProfile };
};

// --- TRAINER API FUNCTIONS ---

// MEMBERS
export const getAssignedMembers = async ({ filters = {}, page = 1, limit = 5 } = {}) => {
    await delay();
    let filtered = filterData(assignedMembers, filters);
    return paginateData(filtered, page, limit);
};

export const getMemberById = async (id) => {
    await delay();
    return assignedMembers.find(m => m.id === parseInt(id) || m.memberId === id);
};

export const flagMember = async (id, reason) => {
    await delay();
    assignedMembers = assignedMembers.map(m =>
        m.id === parseInt(id) || m.memberId === id ? { ...m, isFlagged: true, flagReason: reason } : m
    );
    return true;
};

// SESSIONS
export const getSessions = async ({ filters = {}, page = 1, limit = 10 } = {}) => {
    await delay();
    let filtered = filterData(sessions, filters);
    return paginateData(filtered, page, limit);
};

export const getSessionsByDateRange = async (startDate, endDate) => {
    await delay();
    return sessions.filter(s => {
        const sDate = new Date(s.date);
        return sDate >= new Date(startDate) && sDate <= new Date(endDate);
    });
};

export const updateSessionStatus = async (id, status) => {
    await delay();
    sessions = sessions.map(s => s.id === parseInt(id) ? { ...s, status } : s);
    return sessions.find(s => s.id === parseInt(id));
};

// ATTENDANCE
export const getSessionHistory = async ({ filters = {}, page = 1, limit = 5 } = {}) => {
    await delay();
    let filtered = filterData(sessionHistory, filters);
    return paginateData(filtered, page, limit);
};

export const saveAttendance = async (sessionId, attendanceData) => {
    await delay();
    console.log(`Saving attendance for session ${sessionId}:`, attendanceData);
    return true;
};

// TASKS
export const getTasks = async ({ filters = {}, page = 1, limit = 5 } = {}) => {
    await delay();
    let filtered = filterData(tasks, filters);
    return paginateData(filtered, page, limit);
};

export const updateTaskStatus = async (id, status) => {
    await delay();
    tasks = tasks.map(t => t.id === parseInt(id) ? { ...t, status } : t);
    return tasks.find(t => t.id === parseInt(id));
};

// PAYMENTS (Read-only)
export const getMemberPayments = async (memberId) => {
    await delay();
    // Simplified return for read-only view
    return [
        { id: 1, date: '2024-09-01', amount: 5000, status: 'Paid', method: 'Card' },
        { id: 2, date: '2024-08-01', amount: 5000, status: 'Paid', method: 'UPI' },
    ];
};


// --- MOCK DATA ---

let gyms = [
    { id: 1, gymName: 'FitPulse Elite', branchName: 'Downtown Branch', owner: 'Alex Johnson', phone: '+1 234 567 890', location: '123 Main St, New York, NY', status: 'Active', members: 1250 },
    { id: 2, gymName: 'Iron Paradise', branchName: 'Westside Hub', owner: 'Sarah Connor', phone: '+1 987 654 321', location: '456 Elm St, Los Angeles, CA', status: 'Active', members: 850 },
    { id: 3, gymName: 'Flex Gym', branchName: 'North Station', owner: 'Mike Tyson', phone: '+1 555 123 456', location: '789 Oak Ave, Chicago, IL', status: 'Suspended', members: 0 },
    { id: 4, gymName: 'Urban Fitness', branchName: 'Metro Center', owner: 'Emily Blunt', phone: '+1 333 444 555', location: '321 Pine Rd, Seattle, WA', status: 'Active', members: 2100 },
];

let plans = [
    { id: 1, name: 'Basic Plan', price: '49', period: 'Monthly', features: ['member_management', 'payment_reports'], status: 'Active' },
    { id: 2, name: 'Pro Plan', price: '99', period: 'Monthly', features: ['member_management', 'payment_reports', 'trainer_management', 'task_management'], status: 'Active' },
    { id: 3, name: 'Enterprise Plan', price: '199', period: 'Monthly', features: ['gym_management', 'trainer_management', 'member_management', 'payment_reports', 'analytics_dashboard', 'access_control', 'locker_management', 'booking_system', 'wallet_management', 'task_management'], status: 'Active' },
];

let subscriptions = [
    { id: 'SUB-001', gym: 'FitPulse Elite', plan: 'Pro Plan', subscriber: 'Alex Johnson', startDate: '2023-01-15', endDate: '2024-01-15', status: 'Active', paymentStatus: 'Paid' },
    { id: 'SUB-002', gym: 'Iron Paradise', plan: 'Basic Plan', subscriber: 'Sarah Connor', startDate: '2023-05-20', endDate: '2024-05-20', status: 'Active', paymentStatus: 'Paid' },
    { id: 'SUB-003', gym: 'Flex Gym', plan: 'Pro Plan', subscriber: 'Mike Tyson', startDate: '2022-10-10', endDate: '2023-10-10', status: 'Expired', paymentStatus: 'Overdue' },
    { id: 'SUB-004', gym: 'Urban Fitness', plan: 'Enterprise Plan', subscriber: 'Emily Blunt', startDate: '2023-11-01', endDate: '2024-11-01', status: 'Due', paymentStatus: 'Pending' },
    { id: 'SUB-005', gym: 'FitPulse Elite', plan: 'Basic Plan', subscriber: 'Chris Evans', startDate: '2024-01-01', endDate: '2025-01-01', status: 'Active', paymentStatus: 'Paid' },
    { id: 'SUB-006', gym: 'Iron Paradise', plan: 'Pro Plan', subscriber: 'Natasha Romanoff', startDate: '2024-02-15', endDate: '2025-02-15', status: 'Active', paymentStatus: 'Paid' },
    { id: 'SUB-007', gym: 'Flex Gym', plan: 'Enterprise Plan', subscriber: 'Bruce Banner', startDate: '2024-03-20', endDate: '2025-03-20', status: 'Active', paymentStatus: 'Pending' },
    { id: 'SUB-008', gym: 'Urban Fitness', plan: 'Pro Plan', subscriber: 'Steve Rogers', startDate: '2024-01-10', endDate: '2025-01-10', status: 'Active', paymentStatus: 'Paid' },
    { id: 'SUB-009', gym: 'FitPulse Elite', plan: 'Pro Plan', subscriber: 'Wanda Maximoff', startDate: '2023-12-01', endDate: '2024-12-01', status: 'Active', paymentStatus: 'Paid' },
    { id: 'SUB-010', gym: 'Iron Paradise', plan: 'Basic Plan', subscriber: 'Tony Stark', startDate: '2023-11-15', endDate: '2024-11-15', status: 'Expired', paymentStatus: 'Paid' },
    { id: 'SUB-011', gym: 'Flex Gym', plan: 'Pro Plan', subscriber: 'Stephen Strange', startDate: '2023-10-25', endDate: '2024-10-25', status: 'Expired', paymentStatus: 'Overdue' },
    { id: 'SUB-012', gym: 'Urban Fitness', plan: 'Enterprise Plan', subscriber: 'Peter Parker', startDate: '2024-04-05', endDate: '2025-04-05', status: 'Active', paymentStatus: 'Paid' },
];

let payments = [
    { id: 'PAY-001', gymName: 'FitPulse Elite', amount: '₹25,000', date: '2026-01-28', method: 'UPI', status: 'Success' },
    { id: 'PAY-002', gymName: 'Iron Paradise', amount: '₹18,500', date: '2026-01-29', method: 'Card', status: 'Pending' },
    { id: 'PAY-003', gymName: 'Elite Fitness - Bandra', amount: '₹32,000', date: '2026-01-27', method: 'Bank Transfer', status: 'Failed' },
    { id: 'PAY-004', gymName: 'GymNation - Pune', amount: '₹15,750', date: '2026-01-30', method: 'UPI', status: 'Success' },
    { id: 'PAY-005', gymName: 'BodyBuilders Hub - Delhi', amount: '₹28,900', date: '2026-01-29', method: 'Card', status: 'Pending' },
    { id: 'PAY-006', gymName: 'FitPulse Elite', amount: '₹12,000', date: '2026-01-25', method: 'UPI', status: 'Success' },
    { id: 'PAY-007', gymName: 'Iron Paradise', amount: '₹9,500', date: '2026-01-24', method: 'Card', status: 'Success' },
    { id: 'PAY-008', gymName: 'Elite Fitness - Bandra', amount: '₹45,000', date: '2026-01-23', method: 'Bank Transfer', status: 'Success' },
    { id: 'PAY-009', gymName: 'GymNation - Pune', amount: '₹22,000', date: '2026-01-22', method: 'UPI', status: 'Success' },
    { id: 'PAY-010', gymName: 'BodyBuilders Hub - Delhi', amount: '₹17,000', date: '2026-01-21', method: 'Card', status: 'Success' },
    { id: 'PAY-011', gymName: 'FitPulse Elite', amount: '₹30,000', date: '2026-01-20', method: 'UPI', status: 'Pending' },
    { id: 'PAY-012', gymName: 'Iron Paradise', amount: '₹15,000', date: '2026-01-19', method: 'Bank Transfer', status: 'Failed' },
];

let globalSettings = {
    siteName: 'New Gym',
    contactAddress: '123 Fitness Ave, Mumbai, Maharashtra 400001',
    supportEmail: 'admin@newgym.com',
    contactPhone: '+91 98765 43210',
    invoice: {
        prefix: 'INV-',
        startNumber: '1001',
        gstPercent: '18'
    }
};

let logs = {
    activity: [
        { id: 1, user: 'Admin User', action: 'Updated Settings', affectedMember: 'System-wide', details: 'Changed GST rate to 18%', module: 'General Settings', date: '2026-02-12 10:30 AM', ip: '192.168.1.1' },
        { id: 2, user: 'Vikram Singh', action: 'Added Member', affectedMember: 'John Smith', details: 'New registration for Gold Annual plan', module: 'Member Management', date: '2026-02-12 09:15 AM', ip: '192.168.1.25' },
        { id: 3, user: 'Aditi Rao', action: 'Deleted Invoice', affectedMember: 'Jane Smith', details: 'Removed duplicate invoice INV-1022', module: 'Payments', date: '2026-02-11 04:45 PM', ip: '192.168.1.4' },
        { id: 4, user: 'Admin User', action: 'Logged In', affectedMember: 'Admin Session', details: 'Successful login from Chrome 122', module: 'Auth', date: '2026-02-12 08:00 AM', ip: '192.168.1.1' },
        { id: 5, user: 'Vikram Singh', action: 'Viewed Reports', affectedMember: 'Monthly Revenue', details: 'Exported Financial Report Q4', module: 'Reports', date: '2026-02-11 11:20 AM', ip: '192.168.1.12' },
        { id: 6, user: 'Aditi Rao', action: 'Updated Plan', affectedMember: 'Mike Johnson', details: 'Upgraded to Platinum plan', module: 'Plans', date: '2026-02-10 02:30 PM', ip: '192.168.1.15' },
        { id: 7, user: 'Vikram Singh', action: 'Exported Data', affectedMember: 'Staff Directory', details: 'CSV export for HR audit', module: 'Payments', date: '2026-02-10 01:15 PM', ip: '192.168.1.18' },
        { id: 8, user: 'Admin User', action: 'Added Gym', affectedMember: 'FitPulse Elite', details: 'Initialized Downtown Branch', module: 'Gym Management', date: '2026-02-09 10:00 AM', ip: '192.168.1.20' },
    ],
    hardware: [
        { id: 1, name: 'Main Gym Access', type: 'Biometric', status: 'connected', message: 'Device synced successfully', date: '2024-03-15 10:35 AM' },
        { id: 2, name: 'Turnstile A', type: 'Access Controller', status: 'error', message: 'Connection timeout', date: '2024-03-15 09:00 AM' },
        { id: 3, name: 'Reception RFID', type: 'Card Reader', status: 'connected', message: 'Heartbeat received', date: '2024-03-15 08:55 AM' },
        { id: 4, name: 'Locker Room RFID', type: 'Card Reader', status: 'disconnected', message: 'Device offline', date: '2024-03-15 08:30 AM' },
        { id: 5, name: 'Exit Turnstile', type: 'Turnstile', status: 'connected', message: 'Ready', date: '2024-03-15 08:00 AM' },
        { id: 6, name: 'Server Rack Fan', type: 'Controller', status: 'error', message: 'High temperature detected', date: '2024-03-14 11:45 PM' },
        { id: 7, name: 'Main Gate Access', type: 'Biometric', status: 'connected', message: 'Firmware updated', date: '2024-03-14 10:20 PM' },
        { id: 8, name: 'Pool Area Gate', type: 'RFID', status: 'disconnected', message: 'Low battery warning', date: '2024-03-14 09:15 PM' },
    ],
    error: [
        { id: 1, code: 'ERR-503', message: 'Service Unavailable', module: 'Payment Gateway', severity: 'high', date: '2024-03-15 11:20 AM' },
        { id: 2, code: 'ERR-400', message: 'Invalid Input Data', module: 'Member Form', severity: 'medium', date: '2024-03-15 10:45 AM' },
        { id: 3, code: 'ERR-404', message: 'Resource Not Found', module: 'API', severity: 'low', date: '2024-03-15 09:30 AM' },
        { id: 4, code: 'ERR-500', message: 'Internal Server Error', module: 'Auth Service', severity: 'high', date: '2024-03-15 08:15 AM' },
        { id: 5, code: 'ERR-401', message: 'Unauthorized Access', module: 'Admin Dashboard', severity: 'medium', date: '2024-03-14 11:00 PM' },
        { id: 6, code: 'ERR-504', message: 'Gateway Timeout', module: 'Cloud Functions', severity: 'high', date: '2024-03-14 10:30 PM' },
        { id: 7, code: 'ERR-403', message: 'Forbidden Request', module: 'Storage', severity: 'medium', date: '2024-03-14 09:15 PM' },
        { id: 8, code: 'ERR-429', message: 'Too Many Requests', module: 'Rate Limiter', severity: 'low', date: '2024-03-14 08:00 PM' },
    ],
    webhooks: [
        { id: 'wh_2931', event: 'membership.created', status: 'success', time: '2 mins ago', method: 'POST', endpoint: '/api/v1/webhooks', statusCode: 200, payload: { user: "Rahul", plan: "Gold" } },
        { id: 'wh_2932', event: 'payment.captured', status: 'success', time: '15 mins ago', method: 'POST', endpoint: '/api/v1/razorpay', statusCode: 200, payload: { amount: 2500, status: "captured" } },
        { id: 'wh_2933', event: 'auth.login_failed', status: 'failed', time: '1 hour ago', method: 'POST', endpoint: '/api/v1/auth/login', statusCode: 401, payload: { error: "Invalid credentials" } },
        { id: 'wh_2934', event: 'system.maintenance', status: 'success', time: '3 hours ago', method: 'GET', endpoint: '/api/v1/health', statusCode: 200, payload: { status: "ok" } },
        { id: 'wh_2935', event: 'whatsapp.sent', status: 'success', time: '4 hours ago', method: 'POST', endpoint: '/api/v1/whatsapp', statusCode: 200, payload: { recipient: "+919876543210", template: "welcome_msg" } },
    ]
};

let staff = [
    { id: 1, name: 'Vikram Singh', email: 'vikram@pulse.com', phone: '+91 99999 88888', role: 'Branch Manager', status: 'Active', joinedDate: '2023-01-10', reportingManager: 'None' },
    { id: 2, name: 'Aditi Rao', email: 'aditi@pulse.com', phone: '+91 88888 77777', role: 'Receptionist', status: 'Active', joinedDate: '2023-05-15', reportingManager: 'Vikram Singh' },
    { id: 3, name: 'Karan Sharma', email: 'karan@pulse.com', phone: '+91 77777 66666', role: 'Maintenance', status: 'Inactive', joinedDate: '2022-11-20', reportingManager: 'Vikram Singh' },
    { id: 4, name: 'Sanjana Kapoor', email: 'sanjana@pulse.com', phone: '+91 91234 56789', role: 'Trainer', status: 'Active', joinedDate: '2024-01-05', reportingManager: 'Vikram Singh' },
];

let adminProfile = {
    id: 'ADM-001',
    name: 'Super Admin',
    email: 'admin@newgym.com',
    phone: '+91 98765 43210',
    role: 'SUPER_ADMIN',
    avatar: 'A',
    joinedDate: '2023-01-01',
    status: 'Active',
    lastLogin: '2024-03-15 08:00 AM'
};

// --- API FUNCTIONS ---

// Profile
export const fetchAdminProfile = async () => ({ ...adminProfile });
export const updateAdminProfile = async (updated) => {
    adminProfile = { ...adminProfile, ...updated };
    return { ...adminProfile };
};

// Dashboard Cards
export const fetchDashboardCards = async () => {
    return [
        { title: 'Total Gyms', value: gyms.length, trend: '+5%' },
        { title: 'Total Revenue', value: '₹45,250', trend: '+12%' },
        { title: 'Active Subscriptions', value: subscriptions.filter(s => s.status === 'Active').length, trend: '+8%' },
        { title: 'Growth Rate', value: '24.5%', trend: '+2%' }
    ];
};

// Gyms / Branches
export const fetchAllGyms = async () => [...gyms];
export const addGym = async (gym) => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800));
    const newGym = { ...gym, id: gyms.length + 1, status: 'Active', members: 0 };
    gyms = [...gyms, newGym];
    return newGym;
};
export const editGym = async (id, updatedGym) => {
    gyms = gyms.map(g => g.id === id ? { ...g, ...updatedGym } : g);
    return gyms.find(g => g.id === id);
};
export const deleteGym = async (id) => {
    gyms = gyms.filter(g => g.id !== id);
    return true;
};
export const toggleGymStatus = async (id) => {
    gyms = gyms.map(g => g.id === id ? { ...g, status: g.status === 'Active' ? 'Suspended' : 'Active' } : g);
    return gyms.find(g => g.id === id);
};

// SaaS Plans
export const fetchPlans = async () => [...plans];
export const addPlan = async (plan) => {
    const newPlan = { ...plan, id: plans.length + 1, status: 'Active' };
    plans = [...plans, newPlan];
    return newPlan;
};
export const editPlan = async (id, updatedPlan) => {
    plans = plans.map(p => p.id === id ? { ...p, ...updatedPlan } : p);
    return plans.find(p => p.id === id);
};
export const deletePlan = async (id) => {
    plans = plans.filter(p => p.id !== id);
    return true;
};
export const togglePlanFeature = async (id, feature) => {
    plans = plans.map(p => {
        if (p.id === id) {
            const features = p.features.includes(feature)
                ? p.features.filter(f => f !== feature)
                : [...p.features, feature];
            return { ...p, features };
        }
        return p;
    });
    return plans.find(p => p.id === id);
};

export const updatePlanFeatures = async (id, features) => {
    plans = plans.map(p => p.id === id ? { ...p, features } : p);
    return plans.find(p => p.id === id);
};

// Subscriptions
export const fetchSubscriptions = async () => [...subscriptions];
export const filterSubscriptions = async (status) => {
    if (status === 'All') return [...subscriptions];
    return subscriptions.filter(s => s.status === status);
};
export const toggleSubscriptionStatus = async (id) => {
    subscriptions = subscriptions.map(s => s.id === id ? { ...s, status: s.status === 'Active' ? 'Expired' : 'Active' } : s);
    return subscriptions.find(s => s.id === id);
};

// Payments
export const fetchPayments = async () => [...payments];
export const fetchInvoices = async () => {
    return payments.map(p => ({
        invoiceNo: `INV-${p.id.split('-')[1]}`,
        gymName: p.gymName,
        amount: p.amount,
        date: p.date,
        status: p.status === 'Success' ? 'Paid' : 'Unpaid'
    }));
};
export const updatePaymentStatus = async (id, status) => {
    payments = payments.map(p => p.id === id ? { ...p, status } : p);
    return payments.find(p => p.id === id);
};

// GST Reports
export const fetchGSTReports = async () => {
    return payments.map(p => ({
        invoiceNo: `INV-${p.id.split('-')[1]}`,
        gymName: p.gymName,
        amount: p.amount,
        gstPercent: '18%',
        gstAmount: `₹${(parseFloat(p.amount.replace(/[^0-9.-]+/g, "")) * 0.18).toFixed(2)}`,
        date: p.date
    }));
};

// Global Settings
export const fetchGlobalSettings = async () => ({ ...globalSettings });
export const updateGlobalSettings = async (updated) => {
    globalSettings = { ...globalSettings, ...updated };
    return globalSettings;
};

// Invoice Settings
export const fetchInvoiceSettings = async () => ({ ...globalSettings.invoice });
export const updateInvoiceSettings = async (updated) => {
    globalSettings.invoice = { ...globalSettings.invoice, ...updated };
    return { ...globalSettings.invoice };
};

// Logs
export const fetchActivityLogs = async () => [...logs.activity];
export const fetchHardwareLogs = async () => [...logs.hardware];
export const fetchErrorLogs = async () => [...logs.error];
export const fetchWebhookLogs = async () => [...logs.webhooks];

// Export Mock
export const exportTable = (tableName) => {
    console.log(`Exporting ${tableName} to CSV...`);
    alert(`${tableName} exported successfully! Check console for details.`);
};

export const generatePDF = (reportName) => {
    console.log(`Generating PDF for ${reportName}...`);
    alert(`${reportName} PDF generated and downloaded successfully!`);
};

// Staff Management
export const fetchStaff = async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    return [...staff];
};

export const addStaff = async (member) => {
    await new Promise(resolve => setTimeout(resolve, 800));
    const newMember = { ...member, id: staff.length + 1, joinedDate: new Date().toISOString().split('T')[0] };
    staff = [...staff, newMember];
    return newMember;
};

export const editStaff = async (id, updatedMember) => {
    await new Promise(resolve => setTimeout(resolve, 800));
    staff = staff.map(s => s.id === id ? { ...s, ...updatedMember } : s);
    return staff.find(s => s.id === id);
};

export const deleteStaff = async (id) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    staff = staff.filter(s => s.id !== id);
    return true;
};

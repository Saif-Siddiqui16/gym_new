// --- MOCK DATA ---
let memberProfile = {
    id: 'MEM-2024-005',
    name: 'Vikram Malhotra',
    email: 'vikram.m@example.com',
    phone: '+91 98765 43214',
    role: 'MEMBER',
    avatar: 'V',
    joinedDate: '2024-04-10',
    status: 'Active',
    plan: 'Silver Plan',
    expiryDate: '2024-10-10',
    address: 'Juhu, Mumbai',

    // Membership Business Logic Fields
    membershipStatus: 'Active', // 'Active', 'Expired', 'Payment Pending', 'Frozen'
    membershipStartDate: '2024-04-10',
    membershipExpiryDate: '2024-10-10',
    planValidity: 'Monthly', // 'Monthly' or 'Yearly'

    // Benefit Wallet
    benefitWallet: {
        saunaSessions: 5,
        iceBathCredits: 3,
        ptSessions: 2,
        classCredits: 10
    },

    // Simulated current user role for testing (in real app, this comes from auth context)
    currentUserRole: 'ADMIN' // 'ADMIN', 'MANAGER', or 'MEMBER'
};

// Helper (Shared delay pattern)
const delay = (ms = 300) => new Promise(resolve => setTimeout(resolve, ms));

// --- PROFILE API ---
export const fetchMemberProfile = async () => {
    await delay();
    return { ...memberProfile };
};

export const updateMemberProfile = async (updated) => {
    await delay();
    memberProfile = { ...memberProfile, ...updated };
    return { ...memberProfile };
};

export const upgradePlan = async (newPlan) => {
    await delay();
    memberProfile = { ...memberProfile, plan: newPlan };
    return { ...memberProfile };
};

export const cancelMembership = async () => {
    await delay();
    memberProfile = { ...memberProfile, status: 'Cancelled', plan: 'None' };
    return { ...memberProfile };
};

// --- WALLET API ---
let transactions = [
    { id: 1, title: 'Add Credits (UPI)', date: 'May 12, 11:20 AM', amount: 500.00, type: 'income' },
    { id: 2, title: 'Ice Bath Booking', date: 'May 10, 06:15 PM', amount: 150.00, type: 'spent' },
    { id: 3, title: 'Loyalty Reward Credit', date: 'May 08, 09:00 AM', amount: 100.00, type: 'income' },
    { id: 4, title: 'Sauna Session', date: 'May 05, 07:30 PM', amount: 100.00, type: 'spent' },
    { id: 5, title: 'Add Credits (Card)', date: 'May 01, 10:00 AM', amount: 1000.00, type: 'income' },
];

export const fetchWalletTransactions = async () => {
    await delay();
    return [...transactions];
};

export const addWalletCredit = async (amount) => {
    await delay();
    const newTransaction = {
        id: Date.now(),
        title: 'Add Credits (User)',
        date: new Date().toLocaleString('en-US', { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' }),
        amount: parseFloat(amount),
        type: 'income'
    };
    transactions = [newTransaction, ...transactions];
    return newTransaction;
};

// --- BOOKING API ---
let bookings = [
    { id: 1, type: 'Yoga Class', name: 'Power Vinyasa Flow', date: 'Today, May 15', time: '06:30 PM - 07:30 PM', location: 'Studio A', trainer: 'Sarah Jenkins', status: 'Confirmed' },
    { id: 2, type: 'Personal Training', name: 'Strength & Conditioning', date: 'Tomorrow, May 16', time: '08:00 AM - 09:00 AM', location: 'Weight Area', trainer: 'Mike Ross', status: 'Confirmed' },
    { id: 3, type: 'Facility', name: 'Ice Bath Session', date: 'Fri, May 17', time: '07:00 PM - 07:15 PM', location: 'Recovery Zone', status: 'Pending' },
    { id: 4, type: 'Group Class', name: 'Zumba Dance', date: 'Past, May 10', time: '05:00 PM - 06:00 PM', location: 'Studio B', trainer: 'Maria G', status: 'Completed' },
    { id: 5, type: 'Facility', name: 'Sauna Session', date: 'Past, May 08', time: '08:00 AM - 08:30 AM', location: 'Sauna 1', status: 'Completed' },
    { id: 6, type: 'Personal Training', name: 'HIIT Blast', date: 'Past, May 01', time: '07:00 AM - 08:00 AM', location: 'Turf Area', trainer: 'Alex T', status: 'Cancelled' },
];

export const fetchMemberBookings = async () => {
    await delay();
    return [...bookings];
};

export const cancelBooking = async (id) => {
    await delay();
    bookings = bookings.filter(b => b.id !== id);
    return { success: true, id };
};

export const rescheduleBooking = async (id) => {
    await delay();
    // In a real app, this would take new details. Here we just mock success.
    return { success: true };
};

export const createBooking = async (details) => {
    await delay();
    // Mock booking creation
    return { success: true };
};

// --- MEMBERSHIP MANAGEMENT API ---
export const freezeMembership = async () => {
    await delay();
    if (memberProfile.membershipStatus === 'Active') {
        memberProfile.membershipStatus = 'Frozen';
    }
    return { ...memberProfile };
};

export const unfreezeMembership = async () => {
    await delay();
    if (memberProfile.membershipStatus === 'Frozen') {
        memberProfile.membershipStatus = 'Active';
    }
    return { ...memberProfile };
};

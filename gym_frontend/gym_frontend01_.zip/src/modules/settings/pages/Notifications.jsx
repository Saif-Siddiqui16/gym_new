import React, { useState } from 'react';
import Card from '../../../components/ui/Card';
import Button from '../../../components/ui/Button';
import { Mail, MessageSquare, Smartphone, Plus, Save, Trash2 } from 'lucide-react';
import BranchScopeSelector from '../../../components/common/BranchScopeSelector';
import { BRANCHES } from '../data/mockSettingsData';

const Notifications = () => {
    const [selectedBranch, setSelectedBranch] = useState(null);
    const [activeTab, setActiveTab] = useState('channels'); // channels | templates
    const [templates, setTemplates] = useState([
        { id: 1, name: 'Welcome Email', type: 'Email', subject: 'Welcome to Gym!', body: 'Hi {name}, thanks for joining...' },
        { id: 2, name: 'Payment Reminder', type: 'WhatsApp', subject: '', body: 'Dear {name}, your payment of {amount} is due.' }
    ]);
    const [gateways, setGateways] = useState({
        whatsapp: { provider: 'Twilio', apiKey: 'sk_test_...', number: '+1234567890' },
        sms: { provider: 'MSG91', apiKey: 'auth_key_...', senderId: 'GYMAPP' },
        email: { provider: 'AWS SES', apiKey: 'AKIA...', region: 'us-east-1' }
    });

    return (
        <div className="fade-in space-y-4 sm:space-y-6 p-4 sm:p-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 sm:gap-0">
                <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">Communication Settings</h2>
                <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                    <Button
                        variant={activeTab === 'channels' ? 'primary' : 'outline'}
                        onClick={() => setActiveTab('channels')}
                        className="w-full sm:w-auto"
                    >
                        Gateway Channels
                    </Button>
                    <Button
                        variant={activeTab === 'templates' ? 'primary' : 'outline'}
                        onClick={() => setActiveTab('templates')}
                        className="w-full sm:w-auto"
                    >
                        Message Templates
                    </Button>
                </div>
            </div>

            <BranchScopeSelector
                value={selectedBranch}
                onChange={setSelectedBranch}
                branches={BRANCHES}
            />

            {activeTab === 'channels' ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                    {/* WhatsApp */}
                    <Card title="WhatsApp Integration">
                        <div className="space-y-3 sm:space-y-4">
                            <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
                                <div className="p-2 sm:p-3 bg-green-100 text-green-600 rounded-lg shrink-0"><MessageSquare size={20} className="sm:w-6 sm:h-6" /></div>
                                <div>
                                    <h3 className="font-bold text-sm sm:text-base text-gray-900">WhatsApp Business</h3>
                                    <p className="text-xs sm:text-sm text-gray-500">Configure Twilio or Meta API</p>
                                </div>
                            </div>
                            <div>
                                <label className="text-xs font-bold text-gray-500 uppercase">Provider</label>
                                <select className="w-full p-2 border rounded-lg mt-1 bg-gray-50 text-sm">
                                    <option>Twilio</option>
                                    <option>Meta Cloud API</option>
                                    <option>Interakt</option>
                                </select>
                            </div>
                            <div>
                                <label className="text-xs font-bold text-gray-500 uppercase">API Key / Auth Token</label>
                                <input type="password" value={gateways.whatsapp.apiKey} className="w-full p-2 border rounded-lg mt-1 text-sm" />
                            </div>
                            <div>
                                <label className="text-xs font-bold text-gray-500 uppercase">Sender Number</label>
                                <input type="text" value={gateways.whatsapp.number} className="w-full p-2 border rounded-lg mt-1 text-sm" />
                            </div>
                            <Button variant="primary" className="w-full mt-2">Save Configuration</Button>
                        </div>
                    </Card>

                    {/* SMS */}
                    <Card title="SMS Gateway">
                        <div className="space-y-3 sm:space-y-4">
                            <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
                                <div className="p-2 sm:p-3 bg-blue-100 text-blue-600 rounded-lg shrink-0"><Smartphone size={20} className="sm:w-6 sm:h-6" /></div>
                                <div>
                                    <h3 className="font-bold text-sm sm:text-base text-gray-900">SMS Gateway</h3>
                                    <p className="text-xs sm:text-sm text-gray-500">DLT Registered Headers required (India)</p>
                                </div>
                            </div>
                            <div>
                                <label className="text-xs font-bold text-gray-500 uppercase">Provider</label>
                                <select className="w-full p-2 border rounded-lg mt-1 bg-gray-50 text-sm">
                                    <option>MSG91</option>
                                    <option>Kaleyra</option>
                                    <option>Twilio</option>
                                </select>
                            </div>
                            <div>
                                <label className="text-xs font-bold text-gray-500 uppercase">Auth Key</label>
                                <input type="password" value={gateways.sms.apiKey} className="w-full p-2 border rounded-lg mt-1 text-sm" />
                            </div>
                            <div>
                                <label className="text-xs font-bold text-gray-500 uppercase">Sender ID (6 chars)</label>
                                <input type="text" value={gateways.sms.senderId} className="w-full p-2 border rounded-lg mt-1 text-sm" />
                            </div>
                            <Button variant="primary" className="w-full mt-2">Save Configuration</Button>
                        </div>
                    </Card>
                </div>
            ) : (
                <div className="space-y-4 sm:space-y-6">
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                        <h3 className="text-base sm:text-lg font-bold text-gray-700">Message Templates</h3>
                        <Button size="small" variant="primary" className="w-full sm:w-auto"><Plus size={14} className="sm:w-4 sm:h-4 mr-2" /> New Template</Button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                        {templates.map(tpl => (
                            <Card key={tpl.id} className="relative group">
                                <div className="absolute top-3 sm:top-4 right-3 sm:right-4 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
                                    <button className="p-1.5 sm:p-2 text-blue-600 hover:bg-blue-50 rounded-full"><Save size={14} className="sm:w-4 sm:h-4" /></button>
                                    <button className="p-1.5 sm:p-2 text-red-600 hover:bg-red-50 rounded-full"><Trash2 size={14} className="sm:w-4 sm:h-4" /></button>
                                </div>
                                <div className="flex items-center gap-2 mb-2 sm:mb-3">
                                    <span className={`text-xs font-bold px-2 py-1 rounded uppercase ${tpl.type === 'Email' ? 'bg-orange-100 text-orange-700' : 'bg-green-100 text-green-700'}`}>
                                        {tpl.type}
                                    </span>
                                    <h4 className="font-bold text-sm sm:text-base text-gray-900">{tpl.name}</h4>
                                </div>
                                {tpl.type === 'Email' && (
                                    <div className="mb-2">
                                        <label className="text-xs text-gray-400 uppercase">Subject</label>
                                        <input type="text" defaultValue={tpl.subject} className="w-full text-xs sm:text-sm p-1 border-b focus:outline-none focus:border-indigo-500" />
                                    </div>
                                )}
                                <div>
                                    <label className="text-xs text-gray-400 uppercase">Body Content (Supports {`{variables}`})</label>
                                    <textarea
                                        defaultValue={tpl.body}
                                        rows={3}
                                        className="w-full text-xs sm:text-sm p-2 border rounded bg-gray-50 focus:bg-white focus:ring-1 focus:ring-indigo-500 outline-none mt-1"
                                    />
                                </div>
                            </Card>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default Notifications;

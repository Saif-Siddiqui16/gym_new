
import { createInvoice } from '../finance/invoiceApi';

// Mock Data
let lockers = [
    { id: 101, number: 'L-101', status: 'Available', assignee: null, assigneeId: null, isPaid: true, price: 500 },
    { id: 102, number: 'L-102', status: 'Occupied', assignee: 'Jane Doe', assigneeId: 'MEM-202', isPaid: false, price: 0 },
    { id: 103, number: 'L-103', status: 'Maintenance', assignee: null, assigneeId: null, isPaid: true, price: 500 },
    { id: 104, number: 'L-104', status: 'Available', assignee: null, assigneeId: null, isPaid: false, price: 0 },
    { id: 105, number: 'L-105', status: 'Available', assignee: null, assigneeId: null, isPaid: true, price: 750 },
    { id: 106, number: 'L-106', status: 'Available', assignee: null, assigneeId: null, isPaid: false, price: 0 },
];

export const getLockers = async () => {
    console.log('API: getLockers called. Total lockers:', lockers.length);
    await new Promise(resolve => setTimeout(resolve, 300));
    return [...lockers];
};

export const assignLocker = async (lockerId, memberId, memberName, isPaid = null) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const lockerIndex = lockers.findIndex(l => l.id === parseInt(lockerId));

    if (lockerIndex > -1 && lockers[lockerIndex].status === 'Available') {
        const locker = lockers[lockerIndex];

        // Update locker status
        lockers[lockerIndex] = {
            ...locker,
            status: 'Occupied',
            assignee: memberName,
            assigneeId: memberId,
            isPaid: isPaid !== null ? isPaid : locker.isPaid
        };

        // If paid locker, generate invoice
        if (locker.isPaid && locker.price > 0) {
            try {
                await createInvoice({
                    member: memberName,
                    amount: locker.price,
                    type: `Locker Rental (${locker.number})`,
                    dueDate: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0] // 30 days for locker
                });
            } catch (err) {
                console.error('Failed to create locker invoice:', err);
                // We still continue as the locker is assigned in mock state
            }
        }

        return { success: true, message: 'Locker assigned successfully', data: lockers[lockerIndex] };
    }
    return { success: false, message: 'Locker not available or not found' };
};

export const releaseLocker = async (lockerId) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const lockerIndex = lockers.findIndex(l => l.id === parseInt(lockerId));

    if (lockerIndex > -1) {
        lockers[lockerIndex] = {
            ...lockers[lockerIndex],
            status: 'Available',
            assignee: null,
            assigneeId: null
        };
        return { success: true, message: 'Locker released successfully' };
    }
    return { success: false, message: 'Locker not found' };
};

export const addLocker = async (lockerData) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const newLocker = {
        id: Date.now(),
        ...lockerData,
        status: 'Available',
        assignee: null,
        assigneeId: null
    };
    lockers.push(newLocker);
    return { success: true, message: 'Locker created successfully', data: newLocker };
};

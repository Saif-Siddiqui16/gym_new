// --- MOCK DATA ---
let staffProfile = {
    id: 'STF-5012',
    name: 'Anjali Sharma',
    email: 'anjali.stf@newgym.com',
    phone: '+91 98765 43210',
    role: 'STAFF',
    avatar: 'A',
    joinedDate: '2023-11-01',
    status: 'Active',
    lastLogin: '2024-03-15 09:30 AM',
    address: 'Vasant Vihar, Delhi'
};

// Helper to simulate API delay
const delay = (ms = 300) => new Promise(resolve => setTimeout(resolve, ms));

// --- PROFILE API ---
export const fetchStaffProfile = async () => {
    await delay();
    return { ...staffProfile };
};

export const updateStaffProfile = async (updated) => {
    await delay();
    staffProfile = { ...staffProfile, ...updated };
    return { ...staffProfile };
};

// src/api/staff/memberApi.js

// Mock Data Storage
let members = [
    { id: 'MEM-101', name: 'Rahul Sharma', phone: '9876543210', plan: 'Gold Monthly', status: 'Active', expiry: '2025-12-30', lockerId: '101' },
    { id: 'MEM-102', name: 'Vikram Malhotra', phone: '9876543211', plan: 'Platinum Annual', status: 'Active', expiry: '2026-05-15', lockerId: '102' },
    { id: 'MEM-103', name: 'Amit Verma', phone: '9876543212', plan: 'Silver Monthly', status: 'Expired', expiry: '2025-01-15' },
    { id: 'MEM-104', name: 'Sneha Gupta', phone: '9876543213', plan: 'Gold Monthly', status: 'Inactive', expiry: '2024-11-20' },
    { id: 'MEM-105', name: 'Priya Singh', phone: '9876543215', plan: 'Silver Monthly', status: 'Active', expiry: '2025-11-20' },
    { id: 'MEM-106', name: 'Ananya Ray', phone: '9876543216', plan: 'Gold Monthly', status: 'Active', expiry: '2025-05-12' },
    { id: 'MEM-107', name: 'Kabir Das', phone: '9876543217', plan: 'Platinum Annual', status: 'Inactive', expiry: '2025-06-15' },
];

const delay = (ms = 300) => new Promise(resolve => setTimeout(resolve, ms));

export const getMembers = async () => {
    await delay();
    return [...members];
};

export const getMemberById = async (id) => {
    await delay();
    return members.find(m => m.id === id);
};

export const getMemberStats = async () => {
    await delay();
    return {
        total: members.length,
        active: members.filter(m => m.status === 'Active').length,
        expired: members.filter(m => m.status === 'Expired').length,
        inactive: members.filter(m => m.status === 'Inactive').length,
    };
};

import React from 'react';
import Card from '../../../components/ui/Card';
import StatsCard from '../components/StatsCard';
import DashboardGrid from '../components/DashboardGrid';
import SectionHeader from '../components/SectionHeader';
import { DASHBOARD_DATA } from '../data/mockDashboardData';
import { MapPin, ArrowRight, AlertTriangle, Server, CheckCircle2, TrendingUp, Clock } from 'lucide-react';
import Button from '../../../components/ui/Button';

const SuperAdminDashboard = () => {
    const data = DASHBOARD_DATA.SUPER_ADMIN;

    return (
        <div className="h-[calc(100vh-6rem)] overflow-y-auto pr-2 pb-8 space-y-8 fade-in scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-transparent">
            {/* Enhanced Header */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-6 border-b-2 border-gray-100">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">System Overview</h1>
                    <p className="text-gray-600 text-sm">Monitor platform performance and recent activity</p>
                </div>
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-50 border border-emerald-200 rounded-lg">
                    <CheckCircle2 size={16} className="text-emerald-600" />
                    <span className="text-sm font-semibold text-emerald-700">All Systems Operational</span>
                </div>
            </div>

            {/* Stats Grid with Section Header */}
            <div className="space-y-4">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <TrendingUp size={20} className="text-indigo-600" />
                        <h2 className="text-lg font-bold text-gray-800">Key Metrics</h2>
                    </div>
                    <span className="text-xs text-gray-500 flex items-center gap-1">
                        <Clock size={12} />
                        Updated 2 min ago
                    </span>
                </div>
                <DashboardGrid>
                    {data.stats.map(stat => (
                        <StatsCard key={stat.id} {...stat} />
                    ))}
                </DashboardGrid>
            </div>

            {/* Main Content & Sidebar Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

                {/* Recent Registrations Table */}
                <div className="lg:col-span-2 space-y-4 min-w-0">
                    <div className="flex items-center justify-between">
                        <h2 className="text-lg font-bold text-gray-800">Recent Gym Registrations</h2>
                        <Button
                            variant="outline"
                            size="small"
                            className="group hover:bg-indigo-600 hover:text-white hover:border-indigo-600 text-indigo-600 border-indigo-200 font-semibold transition-all duration-300"
                        >
                            View All
                            <ArrowRight size={14} className="ml-1 group-hover:translate-x-1 transition-transform" />
                        </Button>
                    </div>
                    <Card className="overflow-hidden border border-gray-200 shadow-lg hover:shadow-xl transition-shadow duration-300">
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm text-left">
                                <thead className="bg-gradient-to-r from-gray-50 to-gray-100/50 border-b-2 border-gray-200">
                                    <tr>
                                        <th className="px-4 py-3 text-xs font-bold uppercase tracking-wider text-gray-700">Gym Name</th>
                                        <th className="px-4 py-3 text-xs font-bold uppercase tracking-wider text-gray-700 hidden sm:table-cell">Location</th>
                                        <th className="px-4 py-3 text-xs font-bold uppercase tracking-wider text-gray-700 hidden md:table-cell">Date</th>
                                        <th className="px-4 py-3 text-xs font-bold uppercase tracking-wider text-gray-700">Status</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100">
                                    {data.recentRegistrations.map(gym => (
                                        <tr key={gym.id} className="group hover:bg-gradient-to-r hover:from-indigo-50/50 hover:to-transparent transition-all duration-200 cursor-pointer">
                                            <td className="px-4 py-3">
                                                <div className="flex items-center gap-2 min-w-0">
                                                    <div className="w-9 h-9 flex-shrink-0 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-md group-hover:shadow-lg group-hover:scale-110 transition-all duration-300">
                                                        {gym.gym.charAt(0)}
                                                    </div>
                                                    <span className="font-semibold text-gray-900 group-hover:text-indigo-600 transition-colors truncate">
                                                        {gym.gym}
                                                    </span>
                                                </div>
                                            </td>
                                            <td className="px-4 py-3 text-gray-600 hidden sm:table-cell">
                                                <div className="flex items-center gap-2 min-w-0">
                                                    <div className="w-7 h-7 flex-shrink-0 bg-gray-100 rounded-lg flex items-center justify-center group-hover:bg-indigo-100 transition-colors">
                                                        <MapPin size={13} className="text-indigo-500" />
                                                    </div>
                                                    <span className="font-medium truncate">{gym.location}</span>
                                                </div>
                                            </td>
                                            <td className="px-4 py-3 text-gray-600 font-medium whitespace-nowrap hidden md:table-cell">{gym.date}</td>
                                            <td className="px-4 py-3">
                                                <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold shadow-sm transition-all duration-300 group-hover:scale-105 whitespace-nowrap ${gym.status === 'Active'
                                                    ? 'bg-gradient-to-r from-emerald-50 to-emerald-100 text-emerald-700 border border-emerald-200'
                                                    : 'bg-gradient-to-r from-amber-50 to-amber-100 text-amber-700 border border-amber-200'
                                                    }`}>
                                                    {gym.status}
                                                </span>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </Card>
                </div>

                {/* System Alerts / Sidebar */}
                <div className="lg:col-span-1 space-y-4 min-w-0">
                    <h2 className="text-lg font-bold text-gray-800">System Alerts</h2>
                    <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                        {/* Critical Alert */}
                        <div className="bg-white rounded-xl border-l-4 border-red-500 bg-gradient-to-r from-red-50/80 to-white shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer group">
                            <div className="flex items-start gap-3 p-4">
                                <div className="w-10 h-10 flex-shrink-0 bg-gradient-to-br from-red-500 to-red-600 rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 group-hover:rotate-6 transition-all duration-300">
                                    <Server size={20} className="text-white" strokeWidth={2.5} />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-start justify-between gap-2 mb-1">
                                        <h3 className="font-bold text-red-900 text-sm">Server Load High</h3>
                                        <span className="w-2 h-2 flex-shrink-0 rounded-full bg-red-500 animate-pulse shadow-lg shadow-red-500/50 mt-1"></span>
                                    </div>
                                    <p className="text-xs text-red-700 font-medium mb-2">Database latency &gt; 200ms</p>
                                    <div className="flex items-center gap-2 flex-wrap">
                                        <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded-lg text-xs font-bold">Critical</span>
                                        <span className="text-xs text-gray-500 font-medium">2 min ago</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Warning Alert */}
                        <div className="bg-white rounded-xl border-l-4 border-amber-500 bg-gradient-to-r from-amber-50/80 to-white shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer group">
                            <div className="flex items-start gap-3 p-4">
                                <div className="w-10 h-10 flex-shrink-0 bg-gradient-to-br from-amber-500 to-amber-600 rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 group-hover:rotate-6 transition-all duration-300">
                                    <AlertTriangle size={20} className="text-white" strokeWidth={2.5} />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-start justify-between gap-2 mb-1">
                                        <h3 className="font-bold text-amber-900 text-sm">Pending Approvals</h3>
                                        <span className="px-1.5 py-0.5 flex-shrink-0 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-lg text-xs font-bold shadow-md">Action</span>
                                    </div>
                                    <p className="text-xs text-amber-700 font-medium mb-2">3 New Gyms waiting for review</p>
                                    <div className="flex items-center gap-2 flex-wrap">
                                        <span className="px-2 py-0.5 bg-amber-100 text-amber-700 rounded-lg text-xs font-bold">Pending</span>
                                        <span className="text-xs text-gray-500 font-medium">15 min ago</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SuperAdminDashboard;

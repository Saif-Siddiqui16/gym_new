import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, User, CheckCircle } from 'lucide-react';
import Card from '../../../components/ui/Card';
import Button from '../../../components/ui/Button';
import { CLASSES, TRAINERS } from '../data/mockClasses';

const TrainerAssignment = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const classData = CLASSES.find(c => c.id === id);
    const [selectedTrainer, setSelectedTrainer] = useState(classData?.trainerId || '');

    if (!classData) return <div>Class not found</div>;

    const handleSave = () => {
        alert('Trainer assigned successfully!');
        navigate(`/classes/${id}`);
    };

    return (
        <div className="fade-in" style={{ maxWidth: '800px', margin: '0 auto' }}>
            {/* Header */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: 'var(--space-4)' }}>
                <button onClick={() => navigate(`/classes/${id}`)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--muted)' }}>
                    <ArrowLeft size={20} />
                </button>
                <h2 className="text-title" style={{ margin: 0 }}>Assign Trainer</h2>
            </div>

            <Card className="mb-4">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                        <div style={{ fontSize: '0.875rem', color: 'var(--muted)' }}>Class</div>
                        <div style={{ fontWeight: 600, fontSize: '1.125rem' }}>{classData.name}</div>
                    </div>
                    <div>
                        <div style={{ fontSize: '0.875rem', color: 'var(--muted)' }}>Current Schedule</div>
                        <div style={{ fontWeight: 500 }}>{classData.schedule}</div>
                    </div>
                </div>
            </Card>

            <h3 className="text-title" style={{ fontSize: '1.125rem', marginBottom: '16px' }}>Select Trainer</h3>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 'var(--space-3)' }}>
                {TRAINERS.map(trainer => {
                    const isSelected = selectedTrainer === trainer.id;
                    return (
                        <div
                            key={trainer.id}
                            onClick={() => setSelectedTrainer(trainer.id)}
                            style={{
                                background: 'white',
                                border: isSelected ? '2px solid var(--primary)' : '1px solid var(--border-color)',
                                borderRadius: '12px',
                                padding: '16px',
                                cursor: 'pointer',
                                transition: 'all 0.2s',
                                position: 'relative'
                            }}
                        >
                            {isSelected && <CheckCircle size={20} color="var(--primary)" style={{ position: 'absolute', top: '12px', right: '12px' }} />}
                            <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: '#F3F4F6', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '12px' }}>
                                <User size={20} className="text-muted" />
                            </div>
                            <div style={{ fontWeight: 600 }}>{trainer.name}</div>
                            <div style={{ fontSize: '0.875rem', color: 'var(--muted)' }}>{trainer.specialty}</div>
                        </div>
                    );
                })}
            </div>

            <div style={{ marginTop: '32px', textAlign: 'right' }}>
                <Button variant="outline" onClick={() => navigate(`/classes/${id}`)} style={{ marginRight: '16px' }}>Cancel</Button>
                <Button variant="primary" onClick={handleSave}>Confirm Assignment</Button>
            </div>
        </div>
    );
};

export default TrainerAssignment;

import React, { useState } from 'react';
import { Search, Filter, Calendar, TrendingUp, Users, Banknote, XCircle, CheckCircle, Clock, Download, FileText, ChevronRight, IndianRupee } from 'lucide-react';
import MobileCard from '../../components/common/MobileCard';
import RightDrawer from '../../components/common/RightDrawer';

const payrollHistory = [
    { id: 1, name: 'Mike Tyson', month: 'January 2025', baseSalary: 45000, bonus: 5000, deductions: 2000, netPay: 48000, status: 'Paid', paidDate: '02 Jan 2025' },
    { id: 2, name: 'Sarah Connor', month: 'January 2025', baseSalary: 35000, bonus: 8000, deductions: 1500, netPay: 41500, status: 'Pending', paidDate: '-' },
    { id: 3, name: 'John Wick', month: 'January 2025', baseSalary: 12000, bonus: 0, deductions: 500, netPay: 11500, status: 'Paid', paidDate: '03 Jan 2025' },
];

const PayrollHistory = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [filterStatus, setFilterStatus] = useState('');
    const [selectedEmployee, setSelectedEmployee] = useState(null);
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);

    const filteredRecords = payrollHistory.filter(record => {
        const matchesSearch = record.name.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus = filterStatus === '' || record.status === filterStatus;
        return matchesSearch && matchesStatus;
    });

    const openDrawer = (record) => {
        setSelectedEmployee(record);
        setIsDrawerOpen(true);
    };

    const closeDrawer = () => {
        setIsDrawerOpen(false);
        setTimeout(() => setSelectedEmployee(null), 300);
    };

    return (
        <div className="bg-gradient-to-br from-slate-50 via-white to-violet-50/30 p-4 sm:p-6 pb-12 min-h-screen font-sans">
            {/* Header section... (Copying style from previous modules) */}
            <div className="mb-6 sm:mb-8 relative">
                <div className="absolute inset-0 bg-gradient-to-r from-violet-500 via-purple-500 to-fuchsia-500 rounded-2xl blur-2xl opacity-10 animate-pulse"></div>
                <div className="relative bg-white/80 backdrop-blur-sm rounded-xl sm:rounded-2xl shadow-xl border border-slate-100 p-4 sm:p-6">
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                        <div>
                            <h1 className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-violet-600 via-purple-600 to-fuchsia-600 bg-clip-text text-transparent mb-1 flex items-center gap-2">
                                <FileText className="text-violet-600" size={24} />
                                Payroll History
                            </h1>
                            <p className="text-slate-600 text-xs sm:text-sm">View and manage employee payment history</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Filters Bar */}
            <div className="mb-6 bg-white/60 backdrop-blur-md rounded-2xl shadow-lg border border-white/50 p-4 sm:p-5">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="md:col-span-2 relative group">
                        <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-violet-500 transition-all duration-300" />
                        <input
                            type="text"
                            placeholder="Search by name..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full pl-12 pr-4 py-3 bg-white border-2 border-slate-100 rounded-xl text-sm font-bold text-slate-700 focus:outline-none focus:border-violet-500 focus:ring-4 focus:ring-violet-500/10 transition-all duration-300 hover:border-slate-200 shadow-sm"
                        />
                    </div>

                    <div className="relative">
                        <Filter size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-violet-500 z-10" />
                        <select
                            value={filterStatus}
                            onChange={(e) => setFilterStatus(e.target.value)}
                            className="w-full pl-12 pr-4 py-3 bg-white border-2 border-slate-100 rounded-xl text-sm font-bold text-slate-700 focus:outline-none focus:border-violet-500 focus:ring-4 focus:ring-violet-500/10 transition-all duration-300 appearance-none cursor-pointer hover:border-slate-200 shadow-sm"
                        >
                            <option value="">All Status</option>
                            <option value="Paid">Paid</option>
                            <option value="Pending">Pending</option>
                        </select>
                    </div>

                    <button className="flex items-center justify-center gap-2 py-3 bg-slate-900 text-white rounded-xl text-sm font-black hover:bg-slate-800 transition-all duration-300 shadow-lg shadow-slate-200">
                        <Download size={18} /> Export Data
                    </button>
                </div>
            </div>

            {/* Mobile Cards (md:hidden) */}
            <div className="grid grid-cols-1 gap-4 md:hidden mb-6">
                {filteredRecords.map(record => (
                    <MobileCard
                        key={record.id}
                        title={record.name}
                        subtitle={record.month}
                        badge={{
                            label: record.status,
                            color: record.status === 'Paid' ? 'emerald' : 'amber'
                        }}
                        fields={[
                            { label: 'Net Pay', value: `₹${record.netPay.toLocaleString()}`, icon: IndianRupee },
                            { label: 'Paid On', value: record.paidDate, icon: Calendar },
                        ]}
                        actions={[
                            {
                                label: 'View Details',
                                icon: ChevronRight,
                                variant: 'secondary',
                                onClick: () => openDrawer(record)
                            }
                        ]}
                    />
                ))}
            </div>

            {/* Desktop Table View */}
            <div className="hidden md:block bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden">
                <table className="w-full">
                    <thead>
                        <tr className="bg-slate-50 border-b border-slate-100">
                            <th className="px-6 py-4 text-left text-xs font-black uppercase tracking-widest text-slate-400">Employee</th>
                            <th className="px-6 py-4 text-left text-xs font-black uppercase tracking-widest text-slate-400">Month</th>
                            <th className="px-6 py-4 text-left text-xs font-black uppercase tracking-widest text-slate-400">Net Pay</th>
                            <th className="px-6 py-4 text-left text-xs font-black uppercase tracking-widest text-slate-400">Status</th>
                            <th className="px-6 py-4 text-left text-xs font-black uppercase tracking-widest text-slate-400">Paid Date</th>
                            <th className="px-6 py-4 text-right text-xs font-black uppercase tracking-widest text-slate-400">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {filteredRecords.map(record => (
                            <tr key={record.id} className="group hover:bg-slate-50/50 transition-colors cursor-pointer" onClick={() => openDrawer(record)}>
                                <td className="px-6 py-4">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-xl bg-violet-100 flex items-center justify-center text-violet-600 font-bold border border-violet-200">
                                            {record.name.charAt(0)}
                                        </div>
                                        <span className="text-sm font-black text-slate-900">{record.name}</span>
                                    </div>
                                </td>
                                <td className="px-6 py-4">
                                    <span className="text-sm font-bold text-slate-500">{record.month}</span>
                                </td>
                                <td className="px-6 py-4">
                                    <span className="text-sm font-black text-slate-900">₹{record.netPay.toLocaleString()}</span>
                                </td>
                                <td className="px-6 py-4">
                                    <span className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-widest ${record.status === 'Paid' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                                        {record.status === 'Paid' ? <CheckCircle size={12} /> : <Clock size={12} />}
                                        {record.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 flex flex-col justify-center">
                                    <span className="text-xs font-bold text-slate-400 italic leading-none">{record.paidDate}</span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button
                                        onClick={(e) => { e.stopPropagation(); openDrawer(record); }}
                                        className="p-2 bg-slate-50 text-slate-400 hover:text-violet-600 hover:bg-violet-50 rounded-xl transition-all duration-300"
                                    >
                                        <ChevronRight size={18} />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Payroll Details Drawer */}
            <RightDrawer
                isOpen={isDrawerOpen}
                onClose={closeDrawer}
                title="Payroll Details"
                subtitle={selectedEmployee ? `${selectedEmployee.name} - ${selectedEmployee.month}` : ''}
            >
                {selectedEmployee && (
                    <div className="space-y-8">
                        {/* Header Info */}
                        <div className="bg-gradient-to-br from-violet-600 via-purple-600 to-fuchsia-600 p-6 rounded-2xl text-white shadow-xl">
                            <div className="flex items-center gap-4 mb-4">
                                <div className="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center text-3xl font-black border border-white/30">
                                    {selectedEmployee.name.charAt(0)}
                                </div>
                                <div>
                                    <h2 className="text-2xl font-black tracking-tight">{selectedEmployee.name}</h2>
                                    <div className="text-violet-100 text-sm font-medium">{selectedEmployee.month} History</div>
                                </div>
                            </div>
                            <div className="flex items-center gap-2">
                                <span className={`px-4 py-1.5 rounded-xl text-xs font-black shadow-lg ${selectedEmployee.status === 'Paid' ? 'bg-emerald-400 text-emerald-950' : 'bg-amber-400 text-amber-950'}`}>
                                    {selectedEmployee.status.toUpperCase()}
                                </span>
                            </div>
                        </div>

                        {/* Detailed Stats */}
                        <div className="space-y-4">
                            <div className="flex justify-between items-center py-4 border-b border-slate-100">
                                <span className="text-sm font-bold text-slate-400 uppercase tracking-widest">Base Salary</span>
                                <span className="text-lg font-black text-slate-900">₹{selectedEmployee.baseSalary.toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between items-center py-4 border-b border-slate-100">
                                <span className="text-sm font-bold text-slate-400 uppercase tracking-widest">Incentives</span>
                                <span className="text-lg font-black text-emerald-600">+₹{selectedEmployee.bonus.toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between items-center py-4 border-b border-slate-100">
                                <span className="text-sm font-bold text-slate-400 uppercase tracking-widest">Deductions</span>
                                <span className="text-lg font-black text-red-600">-₹{selectedEmployee.deductions.toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between items-center pt-6">
                                <span className="text-lg font-black text-slate-900 uppercase tracking-widest">Net Payout</span>
                                <span className="text-3xl font-black text-violet-600">₹{selectedEmployee.netPay.toLocaleString()}</span>
                            </div>
                        </div>

                        {/* Payment Info */}
                        <div className="p-6 bg-slate-50 rounded-3xl border border-slate-200">
                            <div className="flex justify-between items-center">
                                <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Paid Date</span>
                                <span className="text-sm font-black text-slate-700">{selectedEmployee.paidDate}</span>
                            </div>
                        </div>

                        {/* Actions */}
                        <div className="pt-6">
                            <button
                                onClick={closeDrawer}
                                className="w-full py-4 px-6 bg-slate-900 text-white rounded-2xl font-black text-lg shadow-xl shadow-slate-200 hover:scale-[1.02] active:scale-95 transition-all"
                            >
                                Close Details
                            </button>
                        </div>
                    </div>
                )}
            </RightDrawer>
        </div>
    );
};

export default PayrollHistory;

// src/api/staff/memberCheckInApi.js

// Mock Data
let members = [
    { id: 'MEM-101', name: 'Rahul Sharma', phone: '9876543210', status: 'Active', expiry: '2025-12-30', checkedIn: false },
    { id: 'MEM-103', name: 'Amit Verma', phone: '9876543212', status: 'Expired', expiry: '2025-01-15', checkedIn: false },
    { id: 'MEM-105', name: 'Priya Singh', phone: '9876543215', status: 'Active', expiry: '2025-11-20', checkedIn: true },
];

export const searchMember = async (query) => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 300));

    if (!query) return null;
    query = query.toLowerCase();

    return members.find(m =>
        m.name.toLowerCase().includes(query) ||
        m.id.toLowerCase().includes(query) ||
        m.phone.includes(query)
    );
};

export const getMemberSuggestions = async (query) => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 200));

    if (!query || query.length < 2) return [];
    query = query.toLowerCase();

    return members.filter(m =>
        m.name.toLowerCase().includes(query) ||
        m.id.toLowerCase().includes(query) ||
        m.phone.includes(query)
    ).slice(0, 5); // Limit to top 5 suggestions
};

export const checkInMember = async (id) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const member = members.find(m => m.id === id);
    if (member) {
        member.checkedIn = true;
        return { success: true, message: 'Check-in successful', data: member };
    }
    return { success: false, message: 'Member not found' };
};

export const checkOutMember = async (id) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const member = members.find(m => m.id === id);
    if (member) {
        member.checkedIn = false;
        return { success: true, message: 'Check-out successful', data: member };
    }
    return { success: false, message: 'Member not found' };
};

export { default as WorkoutPlans } from './pages/WorkoutPlans';

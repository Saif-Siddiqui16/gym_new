import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Search, Plus, Trash2 } from 'lucide-react';
import Card from '../../../components/ui/Card';
import Button from '../../../components/ui/Button';
import { CLASSES, MEMBERS } from '../data/mockClasses';

const MemberEnrollment = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const classData = CLASSES.find(c => c.id === id);

    // Local state to simulate list changes
    const [enrolledIds, setEnrolledIds] = useState(classData?.enrolledMembers || []);
    const [searchTerm, setSearchTerm] = useState('');

    if (!classData) return <div>Class not found</div>;

    const enrolledMembers = MEMBERS.filter(m => enrolledIds.includes(m.id));
    const availableMembers = MEMBERS.filter(m => !enrolledIds.includes(m.id) &&
        (m.name.toLowerCase().includes(searchTerm.toLowerCase()) || m.email.toLowerCase().includes(searchTerm.toLowerCase()))
    );

    const handleEnroll = (memberId) => {
        if (enrolledIds.length >= classData.capacity) {
            alert('Class is full!');
            return;
        }
        setEnrolledIds([...enrolledIds, memberId]);
    };

    const handleRemove = (memberId) => {
        setEnrolledIds(enrolledIds.filter(id => id !== memberId));
    };

    return (
        <div className="fade-in" style={{ maxWidth: '1000px', margin: '0 auto' }}>
            {/* Header */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: 'var(--space-4)' }}>
                <button onClick={() => navigate(`/classes/${id}`)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--muted)' }}>
                    <ArrowLeft size={20} />
                </button>
                <h2 className="text-title" style={{ margin: 0 }}>Manage Enrollments</h2>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-4)' }}>
                {/* Available Members */}
                <Card title="Available Members">
                    <div style={{ position: 'relative', marginBottom: '16px' }}>
                        <Search size={16} className="text-muted" style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)' }} />
                        <input
                            type="text"
                            placeholder="Search members..."
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            style={{ width: '100%', padding: '8px 8px 8px 32px', borderRadius: '6px', border: '1px solid var(--border-color)' }}
                        />
                    </div>
                    <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
                        {availableMembers.map(member => (
                            <div key={member.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid var(--border-color)' }}>
                                <div>
                                    <div style={{ fontWeight: 500 }}>{member.name}</div>
                                    <div style={{ fontSize: '0.75rem', color: 'var(--muted)' }}>{member.email}</div>
                                </div>
                                <Button variant="outline" size="small" onClick={() => handleEnroll(member.id)}>
                                    <Plus size={14} /> Add
                                </Button>
                            </div>
                        ))}
                    </div>
                </Card>

                {/* Enrolled Members */}
                <Card title={`Enrolled (${enrolledIds.length} / ${classData.capacity})`}>
                    <div style={{ maxHeight: '450px', overflowY: 'auto' }}>
                        {enrolledMembers.length > 0 ? (
                            enrolledMembers.map(member => (
                                <div key={member.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px', background: '#F9FAFB', borderRadius: '8px', marginBottom: '8px' }}>
                                    <div>
                                        <div style={{ fontWeight: 500 }}>{member.name}</div>
                                        <div style={{ fontSize: '0.75rem', color: 'var(--muted)' }}>{member.id}</div>
                                    </div>
                                    <button
                                        onClick={() => handleRemove(member.id)}
                                        style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#EF4444' }}
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                            ))
                        ) : (
                            <div className="text-muted text-center p-4">No members enrolled.</div>
                        )}
                    </div>
                </Card>
            </div>
        </div>
    );
};

export default MemberEnrollment;

import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, User, Calendar, MapPin, Users, Edit2, UserPlus } from 'lucide-react';
import Card from '../../../components/ui/Card';
import Button from '../../../components/ui/Button';
import { CLASSES, MEMBERS } from '../data/mockClasses';

const ClassDetails = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const classData = CLASSES.find(c => c.id === id);

    if (!classData) return <div className="p-6 text-center text-muted">Class not found.</div>;

    // Mock enrolled members lookup
    const enrolledMembers = MEMBERS.filter(m => classData.enrolledMembers.includes(m.id));

    return (
        <div className="fade-in">
            {/* Header & Breadcrumb */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--space-4)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)' }}>
                    <button
                        onClick={() => navigate('/classes')}
                        style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--muted)', display: 'flex', alignItems: 'center' }}
                    >
                        <ArrowLeft size={20} />
                    </button>
                    <div>
                        <h2 className="text-title" style={{ marginBottom: '0' }}>{classData.name}</h2>
                        <div className="text-muted" style={{ fontSize: '0.875rem' }}>Class ID: {classData.id}</div>
                    </div>
                </div>

                <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
                    <Button variant="outline" onClick={() => navigate(`/classes/${id}/assign-trainer`)}>
                        <User size={18} style={{ marginRight: '6px' }} />
                        Assign Trainer
                    </Button>
                    <Button variant="outline" onClick={() => navigate(`/classes/${id}/enroll`)}>
                        <UserPlus size={18} style={{ marginRight: '6px' }} />
                        Enroll Members
                    </Button>
                    <Button variant="primary" onClick={() => navigate(`/classes/${id}/edit`)}>
                        <Edit2 size={18} style={{ marginRight: '6px' }} />
                        Edit Class
                    </Button>
                </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: 'var(--space-4)' }}>
                {/* Left Col: Overview */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
                    <Card title="Class Overview">
                        <p style={{ color: 'var(--text)', lineHeight: '1.6', marginBottom: '16px' }}>{classData.description}</p>

                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                            <InfoRow icon={Calendar} label="Schedule" value={classData.schedule} />
                            <InfoRow icon={ClockIcon} label="Duration" value={classData.duration} />
                            <InfoRow icon={MapPin} label="Location" value={classData.location} />
                            <InfoRow icon={Users} label="Capacity" value={`${classData.enrolled} / ${classData.capacity}`} />
                        </div>
                    </Card>

                    <Card title="Trainer Information">
                        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                            <div style={{ width: '56px', height: '56px', borderRadius: '50%', background: '#EFF6FF', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--primary)' }}>
                                <User size={28} />
                            </div>
                            <div>
                                <div style={{ fontWeight: 600, fontSize: '1.125rem' }}>{classData.trainerName}</div>
                                <div className="text-muted" style={{ fontSize: '0.875rem' }}>Assigned Trainer</div>
                            </div>
                        </div>
                    </Card>
                </div>

                {/* Right Col: Enrollments */}
                <div>
                    <Card title={`Enrolled Members (${enrolledMembers.length})`}>
                        {enrolledMembers.length > 0 ? (
                            <ul style={{ listStyle: 'none', padding: 0 }}>
                                {enrolledMembers.map(member => (
                                    <li key={member.id} style={{
                                        padding: '12px 0', borderBottom: '1px solid var(--border-color)',
                                        display: 'flex', alignItems: 'center', justifyContent: 'space-between'
                                    }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                                            <div style={{ width: '32px', height: '32px', borderRadius: '50%', background: '#F9FAFB', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                                <User size={16} className="text-muted" />
                                            </div>
                                            <span style={{ fontWeight: 500 }}>{member.name}</span>
                                        </div>
                                        <span className="text-muted" style={{ fontSize: '0.875rem' }}>{member.email}</span>
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <div className="text-muted" style={{ padding: '20px 0', textAlign: 'center' }}>No members enrolled yet.</div>
                        )}

                        <div style={{ marginTop: '16px', textAlign: 'center' }}>
                            <Button variant="outline" size="small" onClick={() => navigate(`/classes/${id}/enroll`)}>Manage Enrollments</Button>
                        </div>
                    </Card>
                </div>
            </div>
        </div>
    );
};

// Sub-component for icons
const InfoRow = ({ icon: Icon, label, value }) => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
        <span className="text-muted" style={{ fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '4px' }}>
            {Icon && <Icon size={12} />} {label}
        </span>
        <span style={{ fontWeight: 500 }}>{value}</span>
    </div>
);

// Helper
const ClockIcon = ({ size }) => (
    <svg
        xmlns="http://www.w3.org/2000/svg"
        width={size} height={size}
        viewBox="0 0 24 24" fill="none"
        stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
    >
        <circle cx="12" cy="12" r="10"></circle>
        <polyline points="12 6 12 12 16 14"></polyline>
    </svg>
);

export default ClassDetails;

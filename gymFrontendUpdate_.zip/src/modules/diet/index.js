export { default as DietPlans } from './pages/DietPlans';

import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Save, X, Calendar, Upload, ArrowLeft, Sparkles, User, CheckCircle2 } from 'lucide-react';
import { MEMBERSHIPS, BENEFITS } from '../data/mockMemberships';

const PLANS = [
    { name: 'Bronze Quarterly', duration: 3 },
    { name: 'Silver Monthly', duration: 1 },
    { name: 'Gold Annual', duration: 12 },
    { name: 'Platinum Annual', duration: 12 }
];

const MembershipForm = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const isEditMode = !!id;

    // Form State
    const [formData, setFormData] = useState({
        memberId: '',
        planName: 'Gold Annual',
        startDate: new Date().toISOString().split('T')[0],
        endDate: '',
        durationMonths: 12,
        status: 'Active',
        benefits: []
    });

    const fileInputRef = useRef(null);

    // Load Data if Edit Mode
    useEffect(() => {
        if (isEditMode) {
            const membership = MEMBERSHIPS.find(m => m.id === id);
            if (membership) {
                setFormData({
                    memberId: membership.memberId,
                    planName: membership.planName,
                    startDate: membership.startDate,
                    endDate: membership.endDate,
                    durationMonths: membership.durationMonths,
                    status: membership.status,
                    benefits: membership.benefits
                });
            }
        } else {
            // Initial End Date calc
            calculateEndDate(formData.startDate, formData.durationMonths);
        }
        // eslint-disable-next-line
    }, [isEditMode, id]);

    // Auto-calculate End Date
    const calculateEndDate = (start, months) => {
        if (!start) return;
        const date = new Date(start);
        date.setMonth(date.getMonth() + parseInt(months));
        setFormData(prev => ({ ...prev, endDate: date.toISOString().split('T')[0] }));
    };

    const handlePlanChange = (e) => {
        const selectedPlan = PLANS.find(p => p.name === e.target.value);
        if (selectedPlan) {
            setFormData(prev => ({
                ...prev,
                planName: selectedPlan.name,
                durationMonths: selectedPlan.duration
            }));
            calculateEndDate(formData.startDate, selectedPlan.duration);
        }
    };

    const handleDateChange = (e) => {
        setFormData(prev => ({ ...prev, startDate: e.target.value }));
        calculateEndDate(e.target.value, formData.durationMonths);
    };

    const handleBenefitToggle = (benefitId) => {
        setFormData(prev => {
            const newBenefits = prev.benefits.includes(benefitId)
                ? prev.benefits.filter(id => id !== benefitId)
                : [...prev.benefits, benefitId];
            return { ...prev, benefits: newBenefits };
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // In a real app, API call here
        alert(`Membership ${isEditMode ? 'updated' : 'created'} successfully!`);
        navigate('/memberships');
    };

    const handleUploadClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (e) => {
        const file = e.target.files?.[0];
        if (file) {
            console.log('Selected file for Face ID:', file.name);
            alert(`Selected file: ${file.name}\nIn a real app, this would be uploaded and processed for Face ID.`);
        }
    };

    return (
        <div className="bg-gradient-to-br from-gray-50 via-white to-indigo-50/30 p-6 pb-12">
            {/* Premium Header */}
            <div className="max-w-4xl mx-auto mb-8">
                <button
                    onClick={() => navigate('/memberships')}
                    className="flex items-center gap-2 text-gray-600 hover:text-indigo-600 mb-4 transition-colors duration-300 group"
                >
                    <ArrowLeft size={20} className="transition-transform duration-300 group-hover:-translate-x-1" />
                    <span className="font-medium">Back to Memberships</span>
                </button>

                <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-2xl blur-2xl opacity-10 animate-pulse"></div>
                    <div className="relative bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl border border-gray-100 p-6">
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent flex items-center gap-3">
                            <Sparkles className="text-indigo-600" size={28} />
                            {isEditMode ? 'Edit Membership' : 'New Membership'}
                        </h1>
                        <p className="text-gray-600 text-sm mt-2">
                            {isEditMode ? 'Update membership details and benefits' : 'Create a new membership for your member'}
                        </p>
                    </div>
                </div>
            </div>

            <form onSubmit={handleSubmit} className="max-w-4xl mx-auto space-y-6">
                {/* Membership Details Card */}
                <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden hover:shadow-2xl transition-all duration-500">
                    {/* Card Header */}
                    <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6">
                        <h2 className="text-xl font-bold text-white flex items-center gap-2">
                            <User size={20} />
                            Membership Details
                        </h2>
                    </div>

                    {/* Card Content */}
                    <div className="p-8 space-y-6">
                        {/* Member Selection */}
                        <div className="space-y-3 group">
                            <label className="block text-sm font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                                Select Member <span className="text-red-500">*</span>
                            </label>
                            <select
                                value={formData.memberId}
                                onChange={(e) => setFormData(prev => ({ ...prev, memberId: e.target.value }))}
                                disabled={isEditMode}
                                className={`w-full px-5 py-4 bg-gradient-to-br from-white to-indigo-50/30 border-2 border-gray-200 rounded-2xl text-gray-900 text-sm focus:outline-none focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 hover:border-indigo-300 transition-all duration-300 shadow-md ${isEditMode ? 'opacity-60 cursor-not-allowed' : 'hover:shadow-lg'}`}
                            >
                                <option value="">-- Select Member --</option>
                                {MEMBERSHIPS.map(m => (
                                    <option key={m.memberId} value={m.memberId}>{m.memberName} ({m.memberId})</option>
                                ))}
                            </select>
                        </div>

                        {/* Plan & Duration */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-3 group">
                                <label className="block text-sm font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                                    Plan <span className="text-red-500">*</span>
                                </label>
                                <select
                                    value={formData.planName}
                                    onChange={handlePlanChange}
                                    className="w-full px-5 py-4 bg-gradient-to-br from-white to-purple-50/30 border-2 border-gray-200 rounded-2xl text-gray-900 text-sm focus:outline-none focus:ring-4 focus:ring-purple-500/20 focus:border-purple-500 hover:border-purple-300 hover:shadow-lg transition-all duration-300 shadow-md"
                                >
                                    {PLANS.map(p => <option key={p.name} value={p.name}>{p.name}</option>)}
                                </select>
                            </div>

                            <div className="space-y-3 group">
                                <label className="block text-sm font-bold bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent">
                                    Duration (Months)
                                </label>
                                <input
                                    type="number"
                                    value={formData.durationMonths}
                                    disabled
                                    className="w-full px-5 py-4 bg-gray-50 border-2 border-gray-200 rounded-2xl text-gray-600 text-sm shadow-md cursor-not-allowed"
                                />
                            </div>
                        </div>

                        {/* Dates */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-3 group">
                                <label className="block text-sm font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                                    Start Date <span className="text-red-500">*</span>
                                </label>
                                <div className="relative">
                                    <Calendar size={18} className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400 transition-all duration-300 group-focus-within:text-blue-500" />
                                    <input
                                        type="date"
                                        value={formData.startDate}
                                        onChange={handleDateChange}
                                        className="w-full pl-14 pr-5 py-4 bg-gradient-to-br from-white to-blue-50/30 border-2 border-gray-200 rounded-2xl text-gray-900 text-sm focus:outline-none focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 hover:border-blue-300 hover:shadow-lg transition-all duration-300 shadow-md"
                                    />
                                </div>
                            </div>

                            <div className="space-y-3 group">
                                <label className="block text-sm font-bold bg-gradient-to-r from-cyan-600 to-teal-600 bg-clip-text text-transparent">
                                    End Date (Auto-calculated)
                                </label>
                                <input
                                    type="date"
                                    value={formData.endDate}
                                    disabled
                                    className="w-full px-5 py-4 bg-gray-50 border-2 border-gray-200 rounded-2xl text-gray-600 text-sm shadow-md cursor-not-allowed"
                                />
                            </div>
                        </div>

                        {/* Status */}
                        <div className="space-y-3 group">
                            <label className="block text-sm font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                                Status <span className="text-red-500">*</span>
                            </label>
                            <select
                                value={formData.status}
                                onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value }))}
                                className="w-full px-5 py-4 bg-gradient-to-br from-white to-emerald-50/30 border-2 border-gray-200 rounded-2xl text-gray-900 text-sm focus:outline-none focus:ring-4 focus:ring-emerald-500/20 focus:border-emerald-500 hover:border-emerald-300 hover:shadow-lg transition-all duration-300 shadow-md"
                            >
                                <option value="Active">Active</option>
                                <option value="Frozen">Frozen</option>
                                <option value="Expired">Expired</option>
                            </select>
                        </div>

                        {/* Benefits */}
                        <div className="space-y-5 pt-6 border-t-2 border-gray-100">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg">
                                    <CheckCircle2 className="w-6 h-6 text-white" />
                                </div>
                                <h3 className="text-xl font-black bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">Included Benefits</h3>
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                {BENEFITS.map((benefit) => (
                                    <div key={benefit.id} className={`relative flex items-start p-4 rounded-xl border-2 transition-all duration-300 cursor-pointer hover:scale-105 hover:shadow-lg group ${formData.benefits.includes(benefit.id)
                                        ? 'bg-gradient-to-br from-indigo-50 to-purple-50 border-indigo-300 shadow-md'
                                        : 'bg-white border-gray-200 hover:border-indigo-200 hover:bg-indigo-50/30'
                                        }`}>
                                        <div className="flex items-center h-5">
                                            <input
                                                id={benefit.id}
                                                type="checkbox"
                                                className="h-5 w-5 rounded-lg border-2 border-gray-300 text-indigo-600 focus:ring-4 focus:ring-indigo-500/20 transition-all duration-300 cursor-pointer hover:scale-125 checked:scale-125 hover:shadow-lg"
                                                checked={formData.benefits.includes(benefit.id)}
                                                onChange={() => handleBenefitToggle(benefit.id)}
                                            />
                                        </div>
                                        <div className="ml-3 text-sm flex-1">
                                            <label htmlFor={benefit.id} className={`font-semibold cursor-pointer select-none transition-all duration-300 ${formData.benefits.includes(benefit.id)
                                                ? 'text-indigo-700'
                                                : 'text-gray-700 group-hover:text-indigo-600'
                                                }`}>
                                                {benefit.name}
                                            </label>
                                        </div>
                                        {formData.benefits.includes(benefit.id) && (
                                            <div className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full flex items-center justify-center shadow-lg animate-bounce">
                                                <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                                                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                                                </svg>
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>

                {/* Medical & Onboarding Card */}
                <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden hover:shadow-2xl transition-all duration-500">
                    <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-6">
                        <h2 className="text-xl font-bold text-white">Medical & Onboarding</h2>
                    </div>
                    <div className="p-8 space-y-6">
                        <div className="space-y-3 group">
                            <label className="block text-sm font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                                Medical History / Conditions
                            </label>
                            <textarea
                                className="w-full px-5 py-4 bg-gradient-to-br from-white to-purple-50/30 border-2 border-gray-200 rounded-2xl text-gray-900 text-sm placeholder-gray-400 focus:outline-none focus:ring-4 focus:ring-purple-500/20 focus:border-purple-500 hover:border-purple-300 hover:shadow-lg transition-all duration-300 shadow-md resize-none"
                                rows="4"
                                placeholder="Any injuries, surgeries, or conditions we should be aware of?"
                                value={formData.medicalHistory || ''}
                                onChange={e => setFormData({ ...formData, medicalHistory: e.target.value })}
                            />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-3 group">
                                <label className="block text-sm font-bold bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent">
                                    Fitness Goal
                                </label>
                                <select
                                    className="w-full px-5 py-4 bg-gradient-to-br from-white to-pink-50/30 border-2 border-gray-200 rounded-2xl text-gray-900 text-sm focus:outline-none focus:ring-4 focus:ring-pink-500/20 focus:border-pink-500 hover:border-pink-300 hover:shadow-lg transition-all duration-300 shadow-md"
                                    value={formData.fitnessGoal || ''}
                                    onChange={e => setFormData({ ...formData, fitnessGoal: e.target.value })}
                                >
                                    <option value="">Select Goal</option>
                                    <option value="Weight Loss">Weight Loss</option>
                                    <option value="Muscle Gain">Muscle Gain</option>
                                    <option value="Endurance">General Endurance</option>
                                    <option value="Flexibility">Flexibility & Mobility</option>
                                    <option value="Rehabilitation">Rehabilitation</option>
                                </select>
                            </div>

                            <div className="space-y-3 group">
                                <label className="block text-sm font-bold bg-gradient-to-r from-rose-600 to-orange-600 bg-clip-text text-transparent">
                                    Emergency Contact Name
                                </label>
                                <input
                                    type="text"
                                    className="w-full px-5 py-4 bg-gradient-to-br from-white to-rose-50/30 border-2 border-gray-200 rounded-2xl text-gray-900 text-sm placeholder-gray-400 focus:outline-none focus:ring-4 focus:ring-rose-500/20 focus:border-rose-500 hover:border-rose-300 hover:shadow-lg transition-all duration-300 shadow-md"
                                    placeholder="Name"
                                    value={formData.emergencyName || ''}
                                    onChange={e => setFormData({ ...formData, emergencyName: e.target.value })}
                                />
                            </div>
                        </div>

                        <div className="space-y-3 group">
                            <label className="block text-sm font-bold bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                                Emergency Contact Phone
                            </label>
                            <input
                                type="tel"
                                className="w-full px-5 py-4 bg-gradient-to-br from-white to-orange-50/30 border-2 border-gray-200 rounded-2xl text-gray-900 text-sm placeholder-gray-400 focus:outline-none focus:ring-4 focus:ring-orange-500/20 focus:border-orange-500 hover:border-orange-300 hover:shadow-lg transition-all duration-300 shadow-md"
                                placeholder="+91..."
                                value={formData.emergencyPhone || ''}
                                onChange={e => setFormData({ ...formData, emergencyPhone: e.target.value })}
                            />
                        </div>
                    </div>
                </div>

                {/* Biometric Data Card */}
                <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden hover:shadow-2xl transition-all duration-500">
                    <div className="bg-gradient-to-r from-blue-600 to-cyan-600 p-6">
                        <h2 className="text-xl font-bold text-white">Biometric Data</h2>
                    </div>
                    <div className="p-8">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div
                                onClick={handleUploadClick}
                                className="border-2 border-dashed border-indigo-200 rounded-2xl p-12 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-gradient-to-br hover:from-indigo-50 hover:to-purple-50 hover:border-indigo-400 transition-all duration-300 group"
                            >
                                <input
                                    type="file"
                                    ref={fileInputRef}
                                    onChange={handleFileChange}
                                    className="hidden"
                                    accept="image/*"
                                />
                                <div className="w-20 h-20 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                                    <Upload size={32} className="text-white" />
                                </div>
                                <span className="text-base font-bold text-gray-900 mb-1">Upload Face ID Avatar</span>
                                <span className="text-sm text-gray-500">For Turnstile Access</span>
                            </div>
                            <div className="flex items-center justify-center">
                                <ul className="space-y-3 text-gray-600">
                                    <li className="flex items-center gap-2">
                                        <div className="w-2 h-2 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full"></div>
                                        Ensure good lighting
                                    </li>
                                    <li className="flex items-center gap-2">
                                        <div className="w-2 h-2 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full"></div>
                                        Neutral expression
                                    </li>
                                    <li className="flex items-center gap-2">
                                        <div className="w-2 h-2 bg-gradient-to-r from-pink-500 to-rose-600 rounded-full"></div>
                                        No accessories (glasses/hats)
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col-reverse sm:flex-row items-center justify-end gap-4 pt-4">
                    <button
                        type="button"
                        onClick={() => navigate('/memberships')}
                        className="w-full sm:w-auto px-8 py-4 bg-white border-2 border-gray-300 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 hover:border-gray-400 hover:shadow-lg transition-all duration-300 flex items-center justify-center gap-2"
                    >
                        <X size={18} />
                        Cancel
                    </button>
                    <button
                        type="submit"
                        className="group w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl font-semibold shadow-lg hover:shadow-xl hover:shadow-indigo-500/50 hover:scale-105 hover:-translate-y-1 transition-all duration-300 flex items-center justify-center gap-2"
                    >
                        <Save size={18} className="transition-transform duration-300 group-hover:rotate-12" />
                        Save Membership
                    </button>
                </div>
            </form>
        </div>
    );
};

export default MembershipForm;

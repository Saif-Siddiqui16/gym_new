import { paginateData } from './managerPagination';
import { filterData } from './managerFilters';

// Mock Data Storage
let members = [
    { id: 101, name: 'Rahul Sharma', memberId: 'MEM-2024-001', phone: '+91 98765 43210', plan: 'Gold Plan', joinDate: '2024-01-10', expiryDate: '2025-01-10', status: 'Active' },
    { id: 102, name: 'Priya Singh', memberId: 'MEM-2024-002', phone: '+91 98765 43211', plan: 'Silver Plan', joinDate: '2024-02-15', expiryDate: '2024-08-15', status: 'Expired' },
    { id: 103, name: 'Amit Verma', memberId: 'MEM-2024-003', phone: '+91 98765 43212', plan: 'Platinum Plan', joinDate: '2024-03-01', expiryDate: '2025-03-01', status: 'Inactive' },
    { id: 104, name: 'Sneha Gupta', memberId: 'MEM-2024-004', phone: '+91 98765 43213', plan: 'Gold Plan', joinDate: '2024-01-20', expiryDate: '2025-01-20', status: 'Active' },
    { id: 105, name: 'Vikram Malhotra', memberId: 'MEM-2024-005', phone: '+91 98765 43214', plan: 'Silver Plan', joinDate: '2024-04-10', expiryDate: '2024-10-10', status: 'Active' },
    { id: 106, name: 'Ananya Ray', memberId: 'MEM-2024-006', phone: '+91 98765 43215', plan: 'Gold Plan', joinDate: '2024-05-12', expiryDate: '2025-05-12', status: 'Active' },
    { id: 107, name: 'Kabir Das', memberId: 'MEM-2024-007', phone: '+91 98765 43216', plan: 'Platinum Plan', joinDate: '2024-06-15', expiryDate: '2025-06-15', status: 'Inactive' },
];

let bookings = [
    { id: 1, member: 'Vikram Malhotra', memberId: 'MEM-2024-005', type: 'Personal Training', trainer: 'Coach John', slot: '09:00 AM - 10:00 AM', status: 'Completed', date: '2024-03-15' },
    { id: 2, member: 'Sneha Gupta', memberId: 'MEM-2024-004', type: 'Zumba Fusion', trainer: 'Sarah S.', slot: '10:30 AM - 11:30 AM', status: 'Completed', date: '2024-03-15' },
    { id: 3, member: 'Rahul Sharma', memberId: 'MEM-2024-001', type: 'HIIT Workout', trainer: 'Coach Mike', slot: '05:00 PM - 06:00 PM', status: 'Upcoming', date: '2024-03-15' },
    { id: 4, member: 'Priya Singh', memberId: 'MEM-2024-002', type: 'Yoga Basics', trainer: 'Elena V.', slot: '06:30 PM - 07:30 PM', status: 'Upcoming', date: '2024-03-15' },
    { id: 5, member: 'Amit Verma', memberId: 'MEM-2024-003', type: 'Leg Day (PT)', trainer: 'Coach John', slot: '07:30 PM - 08:30 PM', status: 'Cancelled', date: '2024-03-15' },
];

let checkIns = [
    { id: 1, name: 'Alice Johnson', type: 'Member', time: '10:45 AM', status: 'checked-in', avatar: 'A', date: '2024-03-15' },
    { id: 2, name: 'Mike Smith', type: 'Staff', time: '10:42 AM', status: 'checked-in', avatar: 'M', date: '2024-03-15' },
    { id: 3, name: 'Sarah Connor', type: 'Member', time: '10:30 AM', status: 'checked-out', avatar: 'S', date: '2024-03-15' },
    { id: 4, name: 'David Kim', type: 'Member', time: '10:15 AM', status: 'checked-in', avatar: 'D', date: '2024-03-15' },
    { id: 5, name: 'Emily White', type: 'Trainer', time: '10:05 AM', status: 'checked-in', avatar: 'E', date: '2024-03-15' },
];

let tasks = [
    { id: 1, title: 'Check equipment maintenance', assignedTo: 'John Doe', priority: 'High', dueDate: '2025-10-25', status: 'In Progress' },
    { id: 2, title: 'Update membership records', assignedTo: 'Sarah Smith', priority: 'Medium', dueDate: '2025-10-26', status: 'Pending' },
    { id: 3, title: 'Prepare monthly report', assignedTo: 'Mike Wilson', priority: 'Low', dueDate: '2025-10-24', status: 'Completed' },
    { id: 4, title: 'Staff training session', assignedTo: 'Emily Brown', priority: 'High', dueDate: '2025-10-27', status: 'In Progress' },
    { id: 5, title: 'Inventory audit', assignedTo: 'John Doe', priority: 'Medium', dueDate: '2025-10-28', status: 'Pending' },
];

let managerProfile = {
    id: 'MGR-7023',
    name: 'Vikram Singh',
    email: 'vikram.mgr@newgym.com',
    phone: '+91 91234 56789',
    role: 'MANAGER',
    avatar: 'V',
    joinedDate: '2023-06-15',
    status: 'Active',
    lastLogin: '2024-03-15 09:00 AM',
    address: 'Andheri West, Mumbai'
};

// Helper to simulate API delay
const delay = (ms = 300) => new Promise(resolve => setTimeout(resolve, ms));

// --- PROFILE API ---
export const fetchManagerProfile = async () => {
    await delay();
    return { ...managerProfile };
};

export const updateManagerProfile = async (updated) => {
    await delay();
    managerProfile = { ...managerProfile, ...updated };
    return { ...managerProfile };
};

// --- MEMBERS API ---

export const getMembers = async ({ filters = {}, page = 1, limit = 5 } = {}) => {
    await delay();
    let filtered = filterData(members, filters);
    return paginateData(filtered, page, limit);
};

export const getMemberStats = async () => {
    await delay();
    return {
        total: members.length,
        active: members.filter(m => m.status === 'Active').length,
        expired: members.filter(m => m.status === 'Expired').length,
        inactive: members.filter(m => m.status === 'Inactive').length,
        trends: {
            total: '+12%',
            active: '+5%',
            expired: '-2%',
            inactive: '+1%'
        }
    };
};

export const getMemberById = async (id) => {
    await delay();
    return members.find(m => m.id === parseInt(id));
};

export const createMember = async (memberData) => {
    await delay();
    const newMember = { ...memberData, id: Date.now() };
    members = [newMember, ...members];
    return newMember;
};

export const updateMember = async (id, memberData) => {
    await delay();
    members = members.map(m => m.id === parseInt(id) ? { ...m, ...memberData } : m);
    return members.find(m => m.id === parseInt(id));
};

export const deleteMember = async (id) => {
    await delay();
    members = members.filter(m => m.id !== parseInt(id));
    return true;
};

export const toggleMemberStatus = async (id) => {
    await delay();
    members = members.map(m =>
        m.id === parseInt(id) ? { ...m, status: m.status === 'Active' ? 'Inactive' : 'Active' } : m
    );
    return members.find(m => m.id === parseInt(id));
};

// --- BOOKINGS API ---

export const getBookings = async ({ filters = {}, page = 1, limit = 5 } = {}) => {
    await delay();
    let filtered = filterData(bookings, filters);
    return paginateData(filtered, page, limit);
};

export const getBookingStats = async () => {
    await delay();
    return {
        total: bookings.length,
        upcoming: bookings.filter(b => b.status === 'Upcoming').length,
        completed: bookings.filter(b => b.status === 'Completed').length,
        cancelled: bookings.filter(b => b.status === 'Cancelled').length,
    };
};

export const getBookingsByDateRange = async (startDate, endDate) => {
    await delay();
    // Simplified: return all bookings that fall within the range
    return bookings.filter(b => {
        const bDate = new Date(b.date);
        return bDate >= new Date(startDate) && bDate <= new Date(endDate);
    });
};

export const getBookingById = async (id) => {
    await delay();
    return bookings.find(b => b.id === parseInt(id));
};

export const updateBookingStatus = async (id, status) => {
    await delay();
    bookings = bookings.map(b => b.id === parseInt(id) ? { ...b, status } : b);
    return bookings.find(b => b.id === parseInt(id));
};

export const createBooking = async (bookingData) => {
    await delay();
    const newBooking = { ...bookingData, id: Date.now(), status: 'Upcoming' };
    bookings = [newBooking, ...bookings];
    return newBooking;
};

// --- ATTENDANCE API ---

export const getCheckIns = async ({ filters = {}, page = 1, limit = 5 } = {}) => {
    await delay();
    let filtered = filterData(checkIns, filters);
    return paginateData(filtered, page, limit);
};

export const deleteCheckIn = async (id) => {
    await delay();
    checkIns = checkIns.filter(c => c.id !== parseInt(id));
    return true;
};

// --- TASKS API ---

export const getTasks = async ({ filters = {}, page = 1, limit = 5 } = {}) => {
    await delay();
    let filtered = filterData(tasks, filters);
    return paginateData(filtered, page, limit);
};

export const getAttendanceStats = async () => {
    await delay();
    return {
        currentlyIn: checkIns.filter(c => c.status === 'checked-in').length,
        totalToday: checkIns.length,
        membersToday: checkIns.filter(c => c.type === 'Member').length,
        staffToday: checkIns.filter(c => c.type === 'Staff').length
    };
};

export const getTaskStats = async () => {
    await delay();
    return {
        total: tasks.length,
        pending: tasks.filter(t => t.status === 'Pending').length,
        inProgress: tasks.filter(t => t.status === 'In Progress').length,
        completed: tasks.filter(t => t.status === 'Completed').length
    };
};

export const updateTaskStatus = async (id, status) => {
    await delay();
    tasks = tasks.map(t => t.id === parseInt(id) ? { ...t, status } : t);
    return tasks.find(t => t.id === parseInt(id));
};

export const updateTask = async (id, taskData) => {
    await delay();
    tasks = tasks.map(t => t.id === parseInt(id) ? { ...t, ...taskData } : t);
    return tasks.find(t => t.id === parseInt(id));
};

export const createTask = async (taskData) => {
    await delay();
    const newTask = { ...taskData, id: Date.now(), status: 'Pending' };
    tasks = [newTask, ...tasks];
    return newTask;
};

export const deleteTask = async (id) => {
    await delay();
    tasks = tasks.filter(t => t.id !== parseInt(id));
    return true;
};

export const deleteBooking = async (id) => {
    await delay();
    bookings = bookings.filter(b => b.id !== parseInt(id));
    return true;
};

// src/api/staff/paymentApi.js

// Mock Payment History
let payments = [
    { id: 'PAY-001', member: 'Rahul Sharma', plan: 'Gold Monthly', amount: 5000, date: new Date().toISOString().split('T')[0], status: 'Completed', mode: 'Cash' },
    { id: 'PAY-002', member: 'Amit Verma', plan: 'Silver Monthly', amount: 2500, date: new Date().toISOString().split('T')[0], status: 'Pending', mode: 'UPI' },
    { id: 'PAY-003', member: 'Sneha Gupta', plan: 'Gold Monthly', amount: 7000, date: new Date(Date.now() - 86400000).toISOString().split('T')[0], status: 'Completed', mode: 'Card' },
    { id: 'PAY-004', member: 'Vikram Malhotra', plan: 'Platinum Annual', amount: 15000, date: new Date(Date.now() - 172800000).toISOString().split('T')[0], status: 'Completed', mode: 'UPI' },
    { id: 'PAY-005', member: 'Priya Singh', plan: 'Silver Monthly', amount: 2500, date: new Date(Date.now() - 432000000).toISOString().split('T')[0], status: 'Completed', mode: 'Cash' },
    { id: 'PAY-006', member: 'Ananya Ray', plan: 'Gold Monthly', amount: 5000, date: new Date(Date.now() - 604800000).toISOString().split('T')[0], status: 'Completed', mode: 'Card' },
    { id: 'PAY-007', member: 'Kabir Das', plan: 'Platinum Annual', amount: 15000, date: new Date(Date.now() - 2592000000).toISOString().split('T')[0], status: 'Completed', mode: 'UPI' },
];

export const getPaymentHistory = async (filters = {}) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    let filtered = [...payments];

    if (filters.status && filters.status !== 'All') {
        filtered = filtered.filter(p => p.status === filters.status);
    }

    if (filters.mode && filters.mode !== 'All Modes') {
        filtered = filtered.filter(p => p.mode === filters.mode);
    }

    if (filters.search) {
        const search = filters.search.toLowerCase();
        filtered = filtered.filter(p =>
            p.member.toLowerCase().includes(search) ||
            p.id.toLowerCase().includes(search)
        );
    }

    if (filters.dateRange) {
        const now = new Date();
        const today = now.toISOString().split('T')[0];

        if (filters.dateRange === 'Today') {
            filtered = filtered.filter(p => p.date === today);
        } else if (filters.dateRange === 'Last 7 Days') {
            const sevenDaysAgo = new Date(now - 7 * 86400000).toISOString().split('T')[0];
            filtered = filtered.filter(p => p.date >= sevenDaysAgo);
        } else if (filters.dateRange === 'Last 30 Days') {
            const thirtyDaysAgo = new Date(now - 30 * 86400000).toISOString().split('T')[0];
            filtered = filtered.filter(p => p.date >= thirtyDaysAgo);
        }
    }

    return filtered;
};

export const collectPayment = async (paymentData) => {
    await new Promise(resolve => setTimeout(resolve, 800));
    const newPayment = {
        id: `PAY-${Math.floor(Math.random() * 1000 + 10).toString().padStart(3, '0')}`,
        member: paymentData.memberName,
        plan: paymentData.plan || 'N/A',
        amount: paymentData.amount,
        date: new Date().toISOString().split('T')[0],
        status: 'Completed',
        mode: paymentData.paymentMode || 'Cash'
    };
    payments.unshift(newPayment);
    return { success: true, message: 'Payment collected successfully', data: newPayment };
};

// src/api/staff/taskApi.js

// Mock Tasks
let allTasks = [
    { id: 1, title: 'Clean Cardio Area', assignedBy: 'Branch Manager', priority: 'High', due: 'Today, 05:00 PM', status: 'Pending', updated: '2 hours ago' },
    { id: 2, title: 'Restock Towels', assignedBy: 'Admin Staff', priority: 'Medium', due: 'Yesterday', status: 'Completed', updated: 'Yesterday' },
    { id: 3, title: 'Check Equipment Maintenance', assignedBy: 'Branch Manager', priority: 'Low', due: 'Tomorrow', status: 'In Progress', updated: '5 hours ago' },
    { id: 4, title: 'Update Member Records', assignedBy: 'Admin Staff', priority: 'High', due: 'Today, 08:00 PM', status: 'Pending', updated: '1 hour ago' },
    { id: 5, title: 'Sanitize Locker Rooms', assignedBy: 'Manager', priority: 'Medium', due: 'Every 2 Hours', status: 'In Progress', updated: '10 mins ago' },
    { id: 6, title: 'Process New Enrollments', assignedBy: 'Lead Staff', status: 'Pending', updated: '5 hours ago', due: 'Today', priority: 'Medium' },
    { id: 7, title: 'Resolve Billing Dispute - Rahul', assignedBy: 'Manager', status: 'Completed', updated: 'Yesterday', due: 'Yesterday', priority: 'High' },
    { id: 8, title: 'Clean Steam Room', assignedBy: 'Manager', status: 'Pending', updated: '10 mins ago', due: 'Today', priority: 'Low' },
];

export const getMyTasks = async (filters = {}) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    // Simulate "My Tasks" by filtering some
    let filtered = allTasks.filter(t => t.id <= 5);

    if (filters.status && filters.status !== 'All') {
        filtered = filtered.filter(t => t.status === filters.status);
    }

    if (filters.search) {
        const search = filters.search.toLowerCase();
        filtered = filtered.filter(t =>
            t.title.toLowerCase().includes(search) ||
            (t.assignedBy && t.assignedBy.toLowerCase().includes(search))
        );
    }

    return filtered;
};

export const getAllTasks = async (filters = {}) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    let filtered = [...allTasks];

    if (filters.status && filters.status !== 'All') {
        filtered = filtered.filter(t => t.status === filters.status);
    }

    if (filters.search) {
        const search = filters.search.toLowerCase();
        filtered = filtered.filter(t =>
            t.title.toLowerCase().includes(search) ||
            (t.assignedBy && t.assignedBy.toLowerCase().includes(search))
        );
    }

    return filtered;
};

export const updateTaskStatus = async (taskId, newStatus) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    allTasks = allTasks.map(t =>
        t.id === parseInt(taskId) ? { ...t, status: newStatus, updated: 'Just now' } : t
    );
    return { success: true, message: 'Task status updated' };
};

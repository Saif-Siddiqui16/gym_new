import React, { useState, useEffect } from 'react';
import { Search, RotateCcw, Ban, AlertCircle } from 'lucide-react';
import { fetchAllGyms, toggleGymStatus } from '../../api/superadmin/superAdminApi';

const SuspendedGyms = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [gyms, setGyms] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadSuspendedGyms();
    }, []);

    const loadSuspendedGyms = async () => {
        setLoading(true);
        const allGyms = await fetchAllGyms();
        setGyms(allGyms.filter(g => g.status === 'Suspended'));
        setLoading(false);
    };

    const handleReactivate = async (id) => {
        if (window.confirm('Are you sure you want to reactivate this gym?')) {
            await toggleGymStatus(id);
            loadSuspendedGyms();
        }
    };

    const filteredGyms = gyms.filter(gym =>
        gym.gymName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        gym.branchName.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (loading) {
        return <div className="p-6 text-center">Loading suspended gyms...</div>;
    }

    return (
        <div className="w-full">
            {/* Header Section */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 animate-slide-up">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Suspended Gyms</h1>
                    <p className="text-sm text-gray-500 mt-1">Review and manage suspended gym accounts.</p>
                </div>
            </div>

            {/* Warning Banner */}
            <div className="bg-amber-50 border-l-4 border-amber-500 p-4 rounded-r-lg mb-6 animate-slide-up hover:bg-amber-100 hover:shadow-md hover:scale-[1.01] transition-all duration-300 group">
                <div className="flex">
                    <div className="flex-shrink-0">
                        <AlertCircle className="h-5 w-5 text-amber-600 transition-transform duration-300 group-hover:scale-125 group-hover:rotate-12" aria-hidden="true" />
                    </div>
                    <div className="ml-3">
                        <p className="text-sm text-amber-700 transition-colors duration-300 group-hover:text-amber-800">
                            Suspended gyms cannot access the platform until reactivated.
                        </p>
                    </div>
                </div>
            </div>

            {/* Search */}
            <div className="saas-card mb-6 animate-slide-up">
                <div className="relative w-full md:w-96 group">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search className="h-5 w-5 text-gray-400 group-focus-within:text-red-500 transition-colors" />
                    </div>
                    <input
                        type="text"
                        className="saas-input pl-10 transition-all duration-300 focus:scale-[1.02] focus:shadow-lg"
                        placeholder="Search suspended gyms..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
            </div>

            {/* Combined View using Responsive Table */}
            <div className="saas-card p-0 overflow-hidden animate-slide-up delay-200">
                <div className="saas-table-wrapper">
                    <table className="saas-table saas-table-responsive">
                        <thead>
                            <tr>
                                <th>Gym Detail</th>
                                <th>Contact Info</th>
                                <th>Owner</th>
                                <th>Status</th>
                                <th className="text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredGyms.length > 0 ? (
                                filteredGyms.map((gym) => (
                                    <tr key={gym.id} className="hover:bg-red-50/30 hover:shadow-md hover:scale-[1.01] transition-all duration-300 cursor-pointer group">
                                        <td data-label="Gym Detail">
                                            <div className="flex items-center">
                                                <div className="h-10 w-10 flex-shrink-0 rounded-full bg-red-100 flex items-center justify-center text-red-600 font-bold text-lg transition-all duration-300 group-hover:scale-110 group-hover:rotate-6 group-hover:shadow-lg group-hover:bg-red-200">
                                                    {(gym.gymName || '?').charAt(0)}
                                                </div>
                                                <div className="ml-4 text-left">
                                                    <div className="text-sm font-semibold text-gray-900 transition-colors duration-300 group-hover:text-red-600">{gym.gymName}</div>
                                                    <div className="text-sm text-gray-500">{gym.branchName}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td data-label="Contact Info" className="text-left text-sm text-gray-900">{gym.phone}</td>
                                        <td data-label="Owner" className="text-left text-sm text-gray-700">{gym.owner}</td>
                                        <td data-label="Status">
                                            <span className="saas-badge badge-red transition-all duration-300 group-hover:scale-105">
                                                <span className="badge-dot bg-red-600 animate-pulse"></span>
                                                Suspended
                                            </span>
                                        </td>
                                        <td data-label="Actions">
                                            <div className="flex justify-end">
                                                <button
                                                    onClick={() => handleReactivate(gym.id)}
                                                    className="saas-btn saas-btn-primary py-1 px-3 text-xs bg-green-600 hover:bg-green-700 hover:scale-110 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300 group/btn"
                                                >
                                                    <RotateCcw className="w-4 h-4 mr-1 transition-transform duration-300 group-hover/btn:rotate-180" />
                                                    Reactivate
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan="5" className="px-6 py-12 text-center text-gray-500">
                                        <div className="flex flex-col items-center">
                                            <Ban className="h-8 w-8 text-gray-300 mb-2" />
                                            <p>No suspended gyms found.</p>
                                        </div>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default SuspendedGyms;
